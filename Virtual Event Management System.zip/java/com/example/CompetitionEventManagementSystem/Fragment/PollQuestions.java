package com.example.CompetitionEventManagementSystem.Fragment;

import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.CompetitionEventManagementSystem.R;

public class PollQuestions extends Fragment {

    String UserName;
    CardView cq, aq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().setTitle("Poll Questions");
        View view = inflater.inflate(R.layout.fragment_poll_questions, container, false);

        // Retrieve the Username argument from the Bundle
        if (getArguments() != null) {
            UserName = getArguments().getString("UserName");
            Log.d("PollQuestions", "Username received: " + UserName);
        } else {
            Log.d("PollQuestions", "No Username argument received.");
            UserName = "Guest"; // Default value if no username is passed
        }

        cq = view.findViewById(R.id.CQ);
        aq = view.findViewById(R.id.AQ);

        // Click listener for "Create Question" (CQ)
        cq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFragment(new PollCreateQue(), UserName);
            }
        });

        // Click listener for "All Questions" (AQ)
        aq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFragment(new PollAllQuestions(), UserName);
            }
        });

        return view;
    }

    // Method to replace current fragment with the new one and pass UserName
    private void openFragment(Fragment fragment, String userName) {
        Bundle bundle = new Bundle();
        bundle.putString("UserName", userName);
        fragment.setArguments(bundle);

        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}