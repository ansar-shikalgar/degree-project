package com.example.CompetitionEventManagementSystem.Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.CompetitionEventManagementSystem.Adapter.AdapterMeetingL;
import com.example.CompetitionEventManagementSystem.Adapter.AdapterViewEvent;
import com.example.CompetitionEventManagementSystem.Model.ModelMeetingL;
import com.example.CompetitionEventManagementSystem.Model.ModelViewEvent;
import com.example.CompetitionEventManagementSystem.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class F_MeetingLink extends Fragment {

    private RecyclerView recyclerView;
    private AdapterMeetingL adapterMeetingL;
    private List<ModelMeetingL> modelMeetingLList;
    private ProgressBar progressBar;
    String mob;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("View Link");
        View view = inflater.inflate(R.layout.fragment_f__meeting_link, container, false);

        // Retrieve the mobile argument from the Bundle
        if (getArguments() != null) {
            mob = getArguments().getString("Mobile");
            Log.d("Meeting link", "Mobile received: " + mob);
        } else {
            Log.d("Meeting link", "No mobile argument received.");
        }
        recyclerView = view.findViewById(R.id.recview);
        progressBar = view.findViewById(R.id.dynamicProgressBar);

        // Initialize data list and set RecyclerView
        modelMeetingLList = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Fetch data from API
        getLinkData();

        return view;
    }

    private void getLinkData() {
        // Show progress bar before starting data fetch
        progressBar.setVisibility(View.VISIBLE);

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("http://www.testproject.info/CollageEventManagment/CompetitionEventManS_getLink.php")
                .build();

        new Thread(() -> {
            List<ModelMeetingL> list = new ArrayList<>();
            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    Log.e("API_ERROR", "Response failed: " + response.code());
                    return;
                }

                String responseBody = response.body().string();
                Log.d("API_RESPONSE", responseBody);

                JSONArray jsonArray = new JSONArray(responseBody);

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                    ModelMeetingL event = new ModelMeetingL();

                    // ✅ Match keys with your actual response
                    event.setEventId(jsonObject.getInt("Event_ID"));
                    event.setEventname(jsonObject.optString("Event_Name", "Unknown"));
                    event.setEventdate(jsonObject.optString("EventDate", "Unknown"));
                    event.setEventtime(jsonObject.optString("EventTime", "Unknown"));
                    event.setEventLink(jsonObject.optString("Link", "Unknown"));

                    list.add(event);
                }
            } catch (JSONException | IOException e) {
                Log.e("API_ERROR", "Error: " + e.getMessage(), e);
            }

            // Update UI on main thread
            getActivity().runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);

                if (list.isEmpty()) {
                    Toast.makeText(getContext(), "No Event data available", Toast.LENGTH_SHORT).show();
                } else {
                    modelMeetingLList = list;
                    adapterMeetingL = new AdapterMeetingL(getContext(), modelMeetingLList, mob);
                    recyclerView.setAdapter(adapterMeetingL);
                }
            });
        }).start();
    }

}