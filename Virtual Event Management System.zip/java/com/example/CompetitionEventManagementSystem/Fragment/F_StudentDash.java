package com.example.CompetitionEventManagementSystem.Fragment;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.example.CompetitionEventManagementSystem.Adapter.AdapterPicture;
import com.example.CompetitionEventManagementSystem.Adapter.ImageSliderAdapter;
import com.example.CompetitionEventManagementSystem.Model.ModelPicture;
import com.example.CompetitionEventManagementSystem.R;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class F_StudentDash extends Fragment {

    private RecyclerView recyclerView;
    private AdapterPicture adapterPicture;
    private List<ModelPicture> modelPictureList;
    private ProgressBar progressBar;

    private ViewPager2 imageSlider;
    private Handler sliderHandler;
    private Runnable sliderRunnable;
    private int currentSlideIndex = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Home");
        View view= inflater.inflate(R.layout.fragment_f__dash, container, false);

        // Initialize the ViewPager2
        imageSlider = view.findViewById(R.id.viewPager);

        // List of image resources
        int[] images = {
                R.drawable.imge,
                R.drawable.img1,
                R.drawable.img2,
                R.drawable.img3,
                R.drawable.img4
        };

        // Set up the adapter for the ViewPager2
        ImageSliderAdapter adapter = new ImageSliderAdapter(getContext(), images);
        imageSlider.setAdapter(adapter);
        imageSlider.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);

        // Initialize Handler for auto-sliding
        sliderHandler = new Handler(Looper.getMainLooper());

        // Auto-slide logic: switch images every 30 seconds (30000 milliseconds)
        sliderRunnable = new Runnable() {
            @Override
            public void run() {
                if (currentSlideIndex < adapter.getItemCount() - 1) {
                    currentSlideIndex++;
                } else {
                    currentSlideIndex = 0;
                }
                imageSlider.setCurrentItem(currentSlideIndex, true);
                sliderHandler.postDelayed(this, 3000);  // 10 seconds delay
            }
        };

        // Start the auto-slide after initial delay
        sliderHandler.postDelayed(sliderRunnable, 10000);

      // EVENT PICTURES
        recyclerView = view.findViewById(R.id.recview);
        progressBar = view.findViewById(R.id.dynamicProgressBar);

        // Initialize data list and set RecyclerView
        modelPictureList = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Fetch data from API
        getpicture();

        return view;
    }

    private void getpicture() {
        // Show progress bar before starting data fetch
        progressBar.setVisibility(View.VISIBLE);

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("http://tsm.ecssofttech.com/CompetitionEventManS_getPictureNew.php") // API endpoint
                .build();

        // Create a new thread to fetch data (to avoid blocking UI thread)
        new Thread(() -> {
            List<ModelPicture> list = new ArrayList<>();
            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    Log.e("API_ERROR", "Response failed: " + response.code());
                    return;
                }

                String responseBody = response.body().string();
                Log.d("API_RESPONSE", responseBody);

                // Parse the JSON array response
                JSONArray jsonArray = new JSONArray(responseBody);

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                    ModelPicture event = new ModelPicture();

                    event.setEventName(jsonObject.optString("EventName", "Unknown"));
                    event.setImgPath1(jsonObject.optString("Image1", "")); // Set Imgpath
                    event.setImgPath2(jsonObject.optString("Image2", "")); // Set Imgpath
                    event.setImgPath3(jsonObject.optString("Image3", "")); // Set Imgpath
                    event.setImgPath4(jsonObject.optString("Image4", "")); // Set Imgpath

                    list.add(event);
                }
            } catch (JSONException | IOException e) {
                Log.e("API_ERROR", "Error: " + e.getMessage(), e);
            }

            // Update the RecyclerView on the main thread
            if (isAdded()) {
                requireActivity().runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);

                    if (list.isEmpty()) {
                        Toast.makeText(getContext(), "No Event data available", Toast.LENGTH_SHORT).show();
                    } else {
                        modelPictureList = list;
                        adapterPicture = new AdapterPicture(getContext(), modelPictureList);
                        recyclerView.setAdapter(adapterPicture);
                    }
                });
            }

        }).start();

    }
}