package com.example.CompetitionEventManagementSystem.Fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.CompetitionEventManagementSystem.Adapter.AdapterMeetingL;
import com.example.CompetitionEventManagementSystem.Adapter.AdapterSurveyQ;
import com.example.CompetitionEventManagementSystem.Model.ModelMeetingL;
import com.example.CompetitionEventManagementSystem.Model.ModelSurveyQ;
import com.example.CompetitionEventManagementSystem.R;
import com.example.CompetitionEventManagementSystem.StudentDashboard;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class ServeyQueS extends Fragment {

    private RecyclerView recyclerView;
    private AdapterSurveyQ adapterSurveyQ;
    private List<ModelSurveyQ> modelSurveyQS;
    private ProgressBar progressBar;
    String mob;
    String eventName;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Survey Questions");
        View view = inflater.inflate(R.layout.fragment_servey_que_s, container, false);


//        // Retrieve the mobile argument from the Bundle
//        if (getArguments() != null) {
//            mob = getArguments().getString("Mobile");
//            Log.d("SurveyQueS", "Mobile received after : " + mob);
//        } else {
//            Log.d("SurveyQueS", "No mobile argument received.");
//        }
//
//         mob = getArguments().getString("Student_Username");
//        Log.d("SurveyQueS", "Event Name received from for survey Dashboard: " + mob);
//
//         eventName = getArguments().getString("Event_Name");
//        Log.d("SurveyQueS", "Event Name received: " + eventName);


        if (getArguments() != null) {
            mob = getArguments().getString("Mobile");
            if (mob == null) {
                mob = getArguments().getString("Student_Username");
            }
            Log.d("SurveyQueS", "Mobile received after : " + mob);

            eventName = getArguments().getString("Event_Name");
            Log.d("SurveyQueS", "Event Name received: " + eventName);
        } else {
            Log.d("SurveyQueS", "No arguments received.");
        }

        // fetch survey status
        checkSurveyStatus(mob);

        recyclerView = view.findViewById(R.id.recview);
        progressBar = view.findViewById(R.id.dynamicProgressBar);

        // Initialize data list and set RecyclerView
        modelSurveyQS = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Fetch data from API
        getQuestions();

        TextView tvEventName = view.findViewById(R.id.EventName);
        tvEventName.setText(eventName);

        Button btnSave = view.findViewById(R.id.btnSaveAnswers);
        btnSave.setOnClickListener(v -> saveSurveyAnswers());
        return view;
    }

    private void checkSurveyStatus(String mob) {
        OkHttpClient client = new OkHttpClient();

        // Prepare form body (x-www-form-urlencoded)
        RequestBody formBody = new FormBody.Builder()
                .add("Student_Mob", mob)
                .build();

        Request request = new Request.Builder()
                .url("http://www.testproject.info/CollageEventManagment/CompetitionEventManS_CheckSurveyStatus.php")
                .post(formBody)
                .build();

        new Thread(() -> {
            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    Log.e("SURVEY_CHECK", "Request failed: " + response.code());
                    showToast("Survey status check failed");
                    return;
                }

                String result = response.body().string();
                Log.d("SURVEY_CHECK", "Response: " + result);

                // Parse JSON
                JSONObject json = new JSONObject(result);
                String status = json.optString("status");

                if ("Done".equalsIgnoreCase(status)) {
                    requireActivity().runOnUiThread(() -> {
                        F_SurveySubmitted submittedFragment = new F_SurveySubmitted();

                        Bundle bundle = new Bundle();
                        bundle.putString("Mobile", mob);  // Pass the mobile number
                        submittedFragment.setArguments(bundle);

                        getParentFragmentManager().beginTransaction()
                                .replace(R.id.fragment_container, submittedFragment)
                                .addToBackStack(null)
                                .commit();
                    });
                }

            } catch (Exception e) {
                Log.e("SURVEY_CHECK", "Exception: " + e.getMessage(), e);
                showToast("Error checking survey status");
            }
        }).start();
    }

    private void getQuestions() {
        // Show progress bar before starting data fetch
        progressBar.setVisibility(View.VISIBLE);

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("http://www.testproject.info/CollageEventManagment/CompetitionEventManS_getSurveyQ.php")
                .build();

        new Thread(() -> {
            List<ModelSurveyQ> list = new ArrayList<>();
            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    Log.e("API_ERROR", "Response failed: " + response.code());
                    return;
                }

                String responseBody = response.body().string();
                Log.d("API_RESPONSE", responseBody);

                JSONArray jsonArray = new JSONArray(responseBody);

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                    ModelSurveyQ event = new ModelSurveyQ();

                    // ✅ Match keys with your actual response
                    event.setQid(jsonObject.optString("Q_ID","Unknown"));
                    event.setQuestions(jsonObject.optString("Questions", "Unknown"));

                    list.add(event);
                }
            } catch (JSONException | IOException e) {
                Log.e("API_ERROR", "Error: " + e.getMessage(), e);
            }

            // Update UI on main thread
            getActivity().runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);

                if (list.isEmpty()) {
                    Toast.makeText(getContext(), "No Questions data available", Toast.LENGTH_SHORT).show();
                } else {
                    modelSurveyQS = list;
                    adapterSurveyQ = new AdapterSurveyQ(getContext(), modelSurveyQS, eventName,  mob);
                    recyclerView.setAdapter(adapterSurveyQ);
                }
            });
        }).start();
    }

    private void saveSurveyAnswers() {
        if (modelSurveyQS == null || modelSurveyQS.isEmpty()) {
            Toast.makeText(getContext(), "No data to save", Toast.LENGTH_SHORT).show();
            return;
        }

        JSONObject surveyObject = new JSONObject();
        try {
            surveyObject.put("EventName", eventName);
            surveyObject.put("Student_Mob", mob);

            for (int i = 0; i < modelSurveyQS.size(); i++) {
                String key = "Q" + (i + 1); // Q1, Q2, ..., Q10
                String answer = modelSurveyQS.get(i).getAnswer();
                surveyObject.put(key, answer != null ? answer : "Not Answered");
            }

            sendSurveyAnswersToServer(surveyObject);

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Error forming JSON", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendSurveyAnswersToServer(JSONObject surveyObject) {
        OkHttpClient client = new OkHttpClient();

        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(JSON, surveyObject.toString());

        Request request = new Request.Builder()
                .url("http://www.testproject.info/CollageEventManagment/CompetitionEventManS_SaveSurvey.php")
                .post(body)
                .build();

        new Thread(() -> {
            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    Log.e("SURVEY_SUBMIT", "Unsuccessful: " + response.code());
                    showToast("Survey submission failed!");
                    return;
                }

                String result = response.body().string();
                Log.d("SURVEY_SUBMIT", result);
                showToast("Survey Submitted!");

                updateStatus(eventName, mob);

            } catch (IOException e) {
                Log.e("SURVEY_SUBMIT", "Exception: " + e.getMessage(), e);
                showToast("Network error during submission");
            }
        }).start();
    }

    private void showToast(String message) {
        getActivity().runOnUiThread(() ->
                Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show());
    }

    private void updateStatus(String eventN, String studentM) {
        OkHttpClient client = new OkHttpClient();

        // Prepare data to send
        JSONObject json = new JSONObject();
        try {
            json.put("Event_Name", eventN);
            json.put("Student_Username", studentM);
        } catch (JSONException e) {
            e.printStackTrace();
            return;
        }

        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(JSON, json.toString());

        Request request = new Request.Builder()
                .url("http://www.testproject.info/CollageEventManagment/CompetitionEventManS_UpdateStatus.php")
                .post(body)
                .build();

        new Thread(() -> {
            try (Response response = client.newCall(request).execute()) {
                if (response.isSuccessful()) {
                    Log.d("STATUS_UPDATE", "Status updated successfully");
// Now open Student Dashboard on UI thread
                    requireActivity().runOnUiThread(() -> {
                        Intent intent = new Intent(getActivity(), StudentDashboard.class);
                        intent.putExtra("Mobile", studentM); // Pass student mobile number
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        requireActivity().finish(); // Optional: close the current activity
                    });

                } else {
                    Log.e("STATUS_UPDATE", "Failed: " + response.code());
                }
            } catch (IOException e) {
                Log.e("STATUS_UPDATE", "Error: " + e.getMessage(), e);
            }
        }).start();
    }

}