package com.example.CompetitionEventManagementSystem.Fragment;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.CompetitionEventManagementSystem.Dashboard;
import com.example.CompetitionEventManagementSystem.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;


public class PollCreateQue extends Fragment {

    private Spinner spinnerevents;
    private ArrayList<String> eventNames;
    private ArrayList<String> eventIds;
    private ArrayAdapter<String> adapter;

    String UserName;
    EditText QUE;
    Button save;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Create Questions");
        View view = inflater.inflate(R.layout.fragment_poll_create_que, container, false);

        // Retrieve the Username argument from the Bundle
        if (getArguments() != null) {
            UserName = getArguments().getString("UserName");
            Log.d("CreateQuestions", "Username received: " + UserName);
        } else {
            Log.d("CreateQuestions", "No Username argument received.");
            UserName = "Guest"; // Default value if no username is passed
        }
        spinnerevents = view.findViewById(R.id.spinner_events);

        // 🔧 Initialize lists
        eventNames = new ArrayList<>();
        eventIds = new ArrayList<>();

        // Set up spinner
        adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, eventNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerevents.setAdapter(adapter);
        // Fetch events for spinner
        fetchEvents();

        QUE = view.findViewById(R.id.etPollQuestion);
        save = view.findViewById(R.id.btnSubmitPoll);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Que = QUE.getText().toString().trim();

                if (Que.isEmpty()) {
                    Toast.makeText(getContext(), "Type Question", Toast.LENGTH_SHORT).show();
                } else {
                    Save(Que,UserName);  // Fetch numbers & send SMS
                }
            }
        });

        return view;
    }

    private void fetchEvents() {
        String url = "http://www.testproject.info/CollageEventManagment/CollageEventMan_getEventNSpinner.php";
        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Loading events...");
        progressDialog.show();

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    progressDialog.dismiss();
                    try {
                        if (response.getString("status").equals("success")) {
                            JSONArray events = response.getJSONArray("event");
                            for (int i = 0; i < events.length(); i++) {
                                JSONObject event = events.getJSONObject(i);
                                eventNames.add(event.getString("name"));
                                eventIds.add(event.getString("id"));
                            }
                            Log.d("fragment add photo","Event Name" +eventNames);
                            Log.d("fragment add photo","Event id" +eventIds);
                            adapter.notifyDataSetChanged();
                        } else {
                            Toast.makeText(getActivity(), "No events found", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getActivity(), "Error parsing events", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(), "Error fetching events", Toast.LENGTH_SHORT).show();
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(jsonObjectRequest);
    }

    private void Save(String que, String userName) {
        String baseUrl = "http://www.testproject.info/CollageEventManagment/CompetitionEventManS_SaveQue.php";

        // Get selected event name from spinner
        String selectedEvent = spinnerevents.getSelectedItem().toString();

        try {
            userName = URLEncoder.encode(userName, "UTF-8");
            que = URLEncoder.encode(que, "UTF-8");
            selectedEvent = URLEncoder.encode(selectedEvent, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        String API_URL = baseUrl + "?EventName=" + selectedEvent + "&Question=" + que + "&username=" + userName;

        RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest getRequest = new StringRequest(Request.Method.GET, API_URL,
                response -> {
                    if (response.trim().equalsIgnoreCase("Inserted")) {
                        Toast.makeText(getContext(), "Question Saved!", Toast.LENGTH_SHORT).show();
                        showSuccessDialog(UserName);
                    } else if (response.contains("Error")) {
                        Toast.makeText(getContext(), "Failed: " + response, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Unexpected Response: " + response, Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Toast.makeText(getContext(), "Failed to connect!", Toast.LENGTH_SHORT).show();
                });

        queue.add(getRequest);
    }

    private void showSuccessDialog(String userName) {
        new androidx.appcompat.app.AlertDialog.Builder(getContext())
                .setTitle("Success")
                .setMessage("Question Saved Successfully!")
                .setCancelable(false)
                .setPositiveButton("OK", (dialog, which) -> {
                    // Navigate to Dashboard Activity and pass username
                    Intent intent = new Intent(getActivity(), Dashboard.class); // Replace 'Dashboard.class' with your actual activity class name
                    intent.putExtra("UserName", userName);
                    startActivity(intent);
                    getActivity().finish(); // Optional: close current activity/fragment host if needed
                })
                .show();
    }
}