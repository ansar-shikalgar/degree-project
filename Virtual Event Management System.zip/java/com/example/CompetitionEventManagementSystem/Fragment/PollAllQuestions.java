package com.example.CompetitionEventManagementSystem.Fragment;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.CompetitionEventManagementSystem.Adapter.Adapterpollquestion;
import com.example.CompetitionEventManagementSystem.Model.Modelpollallquestion;
import com.example.CompetitionEventManagementSystem.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class PollAllQuestions extends Fragment {

    private RecyclerView recyclerView;
    private Adapterpollquestion pollAdapter;
    private List<Modelpollallquestion> Models;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        getActivity().setTitle("Poll All Questions");

        View view = inflater.inflate(R.layout.fragment_poll_all_questions, container, false);

        recyclerView = view.findViewById(R.id.recyclerview); // Make sure this ID matches your XML
        Models = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        pollAdapter = new Adapterpollquestion(requireContext(), Models);
        recyclerView.setAdapter(pollAdapter);

        fetchPollData();

        return view;
    }

    private void fetchPollData() {
        OkHttpClient client = new OkHttpClient();
        String url = "http://www.testproject.info/CollageEventManagment/fetchquestions.php";

        Request request = new Request.Builder()
                .url(url)
                .build();

        new Thread(() -> {
            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    requireActivity().runOnUiThread(() ->
                            Toast.makeText(requireContext(), "Failed to fetch data", Toast.LENGTH_SHORT).show()
                    );
                    return;
                }

                String responseData = response.body().string();
                Log.d("API_RESPONSE", responseData);

                JSONArray jsonArray = new JSONArray(responseData);
                List<Modelpollallquestion> fetchedList = new ArrayList<>();

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj = jsonArray.getJSONObject(i);
                    Modelpollallquestion model = new Modelpollallquestion(
                            obj.optString("EventName", "N/A"),
                            obj.optString("Question", "N/A"),
                            obj.optString("Username", "N/A"),
                            obj.optInt("Yes_Count", 0),
                            obj.optInt("No_Count", 0),
                            obj.optString("Date_Time", "N/A")
                    );
                    fetchedList.add(model);
                }

                requireActivity().runOnUiThread(() -> {
                    Models.clear();
                    Models.addAll(fetchedList);
                    pollAdapter.notifyDataSetChanged();
                });

            } catch (IOException | JSONException e) {
                e.printStackTrace();
                requireActivity().runOnUiThread(() ->
                        Toast.makeText(requireContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
            }
        }).start();
    }
}
