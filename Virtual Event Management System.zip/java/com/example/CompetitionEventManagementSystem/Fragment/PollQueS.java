package com.example.CompetitionEventManagementSystem.Fragment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.CompetitionEventManagementSystem.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;

public class PollQueS extends Fragment {

    TextView tvQuestion;
    ProgressBar pbYes, pbNo;
    RadioGroup rgAnswers;
    RadioButton rbYes, rbNo;
    Button btnSave;

    int yesCount = 0, noCount = 0, questionId = 0, Time = 0;
    String questionText = "", eventN = "";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Poll Questions");
        return inflater.inflate(R.layout.fragment_poll_que_s, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        tvQuestion = view.findViewById(R.id.tvPollQuestion);
        pbYes = view.findViewById(R.id.pbYes);
        pbNo = view.findViewById(R.id.pbNo);
        rgAnswers = view.findViewById(R.id.rgAnswers);
        rbYes = view.findViewById(R.id.rbYes);
        rbNo = view.findViewById(R.id.rbNo);
        btnSave = view.findViewById(R.id.btnSaveAnswer);

        fetchPollData(); // call when fragment is shown

        btnSave.setOnClickListener(v -> {
            int selectedId = rgAnswers.getCheckedRadioButtonId();
            if (selectedId == -1) {
                Toast.makeText(getContext(), "Please select Yes or No", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean isYes = selectedId == R.id.rbYes;
            updateAnswerCount(isYes);
        });
    }

    private void fetchPollData() {
        String url = "http://www.testproject.info/CollageEventManagment/CompetitionEventManS_FatchQuePoll.php";

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    Log.d("response",response);
                    try {
                        JSONArray array = new JSONArray(response);
                        boolean found = false;

                        // Combine date and time together
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());

                        // Current time
                        Date currentTime = new Date();

                        for (int i = 0; i < array.length(); i++) {
                            JSONObject obj = array.getJSONObject(i);

                            String pollDate = obj.getString("Date"); // e.g., 2025-04-04
                            String pollTime = obj.getString("Time"); // e.g., 05:55:00

                            String fullDateTimeStr = pollDate + " " + pollTime;
                            Date pollStart = sdf.parse(fullDateTimeStr);

                            // Add 24 hours to poll start time
                            Calendar calendar = Calendar.getInstance();
                            calendar.setTime(pollStart);
                            calendar.add(Calendar.HOUR_OF_DAY, 24);
                            Date pollEnd = calendar.getTime();

                            // Check if current time is within the 24-hour window
                            if (currentTime.compareTo(pollStart) >= 0 && currentTime.compareTo(pollEnd) <= 0) {
                                questionId = obj.getInt("Id");
                                questionText = obj.getString("Question");
                                yesCount = obj.optInt("Yes_Count", 0);
                                noCount = obj.optInt("No_Count", 0);
                                eventN = obj.getString("EventName");

                                tvQuestion.setText(questionText);
                                updateProgressBars();
                                found = true;
                                break;
                            }
                        }

                        if (!found) {
                            Toast.makeText(getContext(), "No poll available at this time", Toast.LENGTH_SHORT).show();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(getContext(), "Error parsing data", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(getContext(), "Failed to load poll", Toast.LENGTH_SHORT).show());

        Volley.newRequestQueue(getContext()).add(request);
    }


    private void updateProgressBars() {
        int total = yesCount + noCount;
        int yesPercent = total == 0 ? 0 : (yesCount * 100 / total);
        int noPercent = total == 0 ? 0 : (noCount * 100 / total);

        pbYes.setProgress(yesPercent);
        pbNo.setProgress(noPercent);
    }

    private void updateAnswerCount(boolean isYes) {
        String url = "http://www.testproject.info/CollageEventManagment/CompetitionEventManS_updatePoll.php?Id="
                + questionId + "&answer=" + (isYes ? "Yes" : "No");

        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    if (response.trim().equalsIgnoreCase("Updated")) {
                        Toast.makeText(getContext(), "Answer Saved!", Toast.LENGTH_SHORT).show();
                        if (isYes) yesCount++; else noCount++;
                        updateProgressBars();
                    } else {
                        Toast.makeText(getContext(), "Error: " + response, Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(getContext(), "Failed to update answer", Toast.LENGTH_SHORT).show());

        Volley.newRequestQueue(getContext()).add(request);
    }
}
