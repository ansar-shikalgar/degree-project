package com.example.CompetitionEventManagementSystem.Fragment;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.example.CompetitionEventManagementSystem.Adapter.AdapterSCertificate;
import com.example.CompetitionEventManagementSystem.Adapter.AdapterViewEvent;
import com.example.CompetitionEventManagementSystem.Model.ModelSCertificate;
import com.example.CompetitionEventManagementSystem.Model.ModelViewEvent;
import com.example.CompetitionEventManagementSystem.R;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class F_Student_DCerti extends Fragment {
    private String mob;
    private ProgressBar progressBar;
    private String prn;
    private RecyclerView recyclerView;
    private AdapterSCertificate adapterSCertificate;
    private List<ModelSCertificate> modelSCertificateList;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Retrieve the mobile argument from the Bundle
        if (getArguments() != null) {
            mob = getArguments().getString("Mobile");
            Log.d("Student Certificate", "Mobile received: " + mob);
        } else {
            Log.d("Student Certificate", "No mobile argument received.");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().setTitle("Download Certificate");
        View view = inflater.inflate(R.layout.fragment_f__student__d_certi, container, false);

        // Initialize UI elements
        progressBar = view.findViewById(R.id.dynamicProgressBar); // Ensure you have a ProgressBar in your layout

        // Fetch the PRN number from the API
        getPRNNo();

        recyclerView = view.findViewById(R.id.recview);

        modelSCertificateList = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));


        return view;
    }

    private void getPRNNo() {
        progressBar.setVisibility(View.VISIBLE); // Show progress bar while fetching data

        String url = "http://www.testproject.info/CollageEventManagment/ComEveMS_getPRNFromMob.php?Mobile=" + mob;
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        new Thread(() -> {
            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    Log.e("API_ERROR", "API call failed with response code: " + response.code());
                    showToast("Failed to fetch PRN Number");
                    return;
                }

                // Parse the JSON response
                String responseBody = response.body().string();
                Log.d("API_RESPONSE", "Response: " + responseBody);

                if (responseBody.startsWith("{")) {
                    // Case 1: Response is a JSONObject (Error case)
                    JSONObject jsonObject = new JSONObject(responseBody);
                    if (jsonObject.has("error")) {
                        String errorMessage = jsonObject.getString("error");
                        Log.e("API_ERROR", "Error: " + errorMessage);
                        showToast(errorMessage);
                        return;
                    }
                } else if (responseBody.startsWith("[")) {
                    // Case 2: Response is a JSONArray (Success case)
                    JSONArray jsonResponse = new JSONArray(responseBody);
                    if (jsonResponse.length() > 0) {
                        JSONObject firstObject = jsonResponse.getJSONObject(0);
                        prn = firstObject.optString("PRNNo", null);
                        Log.d("API_RESPONSE", "PRN No: " + prn);
                    }

                    showToast(prn != null ? "PRN No: " + prn : "PRN Number not found.");

                    if (prn != null) {
                        getCertificate(prn);
                    }
                } else {
                    Log.e("API_ERROR", "Unexpected response format");
                    showToast("Unexpected response format");
                }

            } catch (IOException | JSONException e) {
                Log.e("API_ERROR", "Error: " + e.getMessage(), e);
                showToast("Error fetching PRN Number");
            }
        }).start();
    }

    // Helper method to show toast messages
    private void showToast(String message) {
        if (getActivity() != null) {
            getActivity().runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void getCertificate(String prn) {
        // Show progress bar before starting data fetch
        progressBar.setVisibility(View.VISIBLE);

        // Build the URL with PRNNo parameter
        String url = "http://tsm.ecssofttech.com/CompetitionEventManS_getCertificateNew.php?PRNNo=" + prn;

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url) // API endpoint with PRNNo parameter
                .build();

        // Create a new thread to fetch data (to avoid blocking UI thread)
        new Thread(() -> {
            List<ModelSCertificate> list = new ArrayList<>();
            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    Log.e("API_ERROR", "Response failed: " + response.code());
                    return;
                }

                String responseBody = response.body().string();
                Log.d("API_RESPONSE", responseBody);

                // Parse the JSON array response
                JSONArray jsonArray = new JSONArray(responseBody);

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                    ModelSCertificate certi = new ModelSCertificate();

                    certi.setEventN(jsonObject.optString("Ename", "Unknown")); // Event name
                    certi.setCimgpath(jsonObject.optString("Certificatelmgpath", "")); // Certificate image path (can be empty)
                    certi.setPdfpath(jsonObject.optString("pdf", "")); // PDF URL

                    list.add(certi);
                }
            } catch (JSONException | IOException e) {
                Log.e("API_ERROR", "Error: " + e.getMessage(), e);
            }

            // Update the RecyclerView on the main thread
            getActivity().runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);

                if (list.isEmpty()) {
                    Toast.makeText(getContext(), "No Certificate available", Toast.LENGTH_SHORT).show();
                } else {
                    modelSCertificateList = list;
                    // Initialize adapter with the fetched data
                    adapterSCertificate = new AdapterSCertificate(getContext(), modelSCertificateList);
                    recyclerView.setAdapter(adapterSCertificate);
                }
            });
        }).start();  // Start the thread to fetch data
    }
}
