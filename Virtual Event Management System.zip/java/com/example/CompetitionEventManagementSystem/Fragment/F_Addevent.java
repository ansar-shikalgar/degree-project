package com.example.CompetitionEventManagementSystem.Fragment;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.icu.text.SimpleDateFormat;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.example.CompetitionEventManagementSystem.Dashboard;
import com.example.CompetitionEventManagementSystem.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class F_Addevent extends Fragment {

    private EditText dateEditText, timeEditText, name, categ, entryFee;
    private ImageView imgView;
    private Uri imageUri;
    private static final int PICK_IMAGE = 1;
    private static final int REQUEST_CODE_STORAGE_PERMISSION = 101;
    private Bitmap selectedImageBitmap;
    private Button addEventButton;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_f__addevent, container, false);

        // Initialize views
        name = view.findViewById(R.id.Ename);
        categ = view.findViewById(R.id.cate);
        dateEditText = view.findViewById(R.id.date);
        timeEditText = view.findViewById(R.id.time);
        entryFee = view.findViewById(R.id.entryfee);
        imgView = view.findViewById(R.id.img);
        addEventButton = view.findViewById(R.id.addE);

        // Initialize event listeners
        dateEditText.setOnClickListener(v -> openDatePicker());
        timeEditText.setOnClickListener(v -> openTimePicker());
        imgView.setOnClickListener(v -> selectImageFromGallery());
        addEventButton.setOnClickListener(v -> addEvent());

        // Request storage permission if not already granted
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_CODE_STORAGE_PERMISSION);
        }
        return view;
    }

    private void openTimePicker() {
        final Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(requireContext(),
                (view, hourOfDay, minute1) -> timeEditText.setText(String.format("%02d:%02d:00", hourOfDay, minute1)), hour, minute, true);
        timePickerDialog.show();

    }

    private void openDatePicker() {

        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext(),
                (view, year1, monthOfYear, dayOfMonth) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(year1, monthOfYear, dayOfMonth);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    dateEditText.setText(dateFormat.format(selectedDate.getTime()));
                }, year, month, day);
        datePickerDialog.show();
    }

    private void selectImageFromGallery() {

        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE && resultCode == getActivity().RESULT_OK && data != null) {
            imageUri = data.getData();
            try {
                selectedImageBitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);
                imgView.setImageBitmap(selectedImageBitmap);
            } catch (IOException e) {
                e.printStackTrace();
                Log.e("AddEqui", "Error loading image: " + e.getMessage());
            }
        }
    }

    private String convertImageToBase64(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    private void addEvent() {

        String EName = name.getText().toString().trim();
        String ECate = categ.getText().toString().trim();
        String Edate = dateEditText.getText().toString().trim();
        String Etime = timeEditText.getText().toString().trim();
        String EntryFee = entryFee.getText().toString().trim();

        if (EName.isEmpty() || ECate.isEmpty() || Edate.isEmpty() || Etime.isEmpty() || selectedImageBitmap == null) {
            Toast.makeText(getContext(), "Please fill in all fields and select an image", Toast.LENGTH_SHORT).show();
            return;
        }

        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        String imageBase64 = convertImageToBase64(selectedImageBitmap);
        uploadImageToServer(EName, ECate, Edate, Etime, EntryFee, imageBase64, progressDialog);
    }

    private void uploadImageToServer(String eName, String eCate, String edate, String etime, String entryfee, String imageBase64, ProgressDialog progressDialog) {

        class AsyncTaskUploadClass extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog.setMessage("Uploading Image and Data...");
            }

            @Override
            protected String doInBackground(Void... voids) {
                String serverUploadUrl = "http://tsm.ecssofttech.com/CompetitionEventManS_AddEventNewPoll.php";
                imageProcessClass imageProcessClass = new imageProcessClass();

                HashMap<String, String> postData = new HashMap<>();
                postData.put("Ename", eName);
                postData.put("ECategory", eCate);
                postData.put("Date", edate);
                postData.put("Time", etime);
                postData.put("EntryFee", entryfee);
                postData.put("Image", imageBase64);

                return imageProcessClass.ImageHttpRequest(serverUploadUrl, postData);
            }

            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);
                progressDialog.dismiss();

                try {
                    JSONObject jsonResponse = new JSONObject(result);
                    String status = jsonResponse.getString("status");
                    String message = jsonResponse.getString("message");

                    if (status.equals("success")) {
                        showSuccessDialog();
                    } else {
                        Toast.makeText(getActivity(), "Failed to add equipment: " + message, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    Toast.makeText(getActivity(), "Error parsing response: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }

        new AsyncTaskUploadClass().execute();


    }
    public class imageProcessClass {

        public String ImageHttpRequest(String requestURL, HashMap<String, String> postData) {
            StringBuilder stringBuilder = new StringBuilder();

            try {
                URL url = new URL(requestURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setReadTimeout(19000);
                httpURLConnection.setConnectTimeout(19000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.setDoOutput(true);

                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                bufferedWriter.write(getPostDataString(postData));
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                int responseCode = httpURLConnection.getResponseCode();
                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line);
                    }
                    bufferedReader.close();
                } else {
                    return "Error: " + responseCode;
                }

            } catch (IOException e) {
                e.printStackTrace();
                return "IOException: " + e.getMessage();
            }

            return stringBuilder.toString();
        }

        private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
            StringBuilder result = new StringBuilder();

            for (Map.Entry<String, String> entry : params.entrySet()) {
                if (result.length() > 0) result.append("&");
                result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
            }

            return result.toString();
        }
    }

    private void showSuccessDialog() {
        new androidx.appcompat.app.AlertDialog.Builder(getContext())
                .setTitle("Event Added Successfully")
                .setMessage("The Event has been added.")
                .setPositiveButton("OK", (dialog, which) -> {
                    startActivity(new Intent(getActivity(), Dashboard.class));
                    getActivity().finishAffinity();
                })
                .setCancelable(false)
                .show();

    }

}
