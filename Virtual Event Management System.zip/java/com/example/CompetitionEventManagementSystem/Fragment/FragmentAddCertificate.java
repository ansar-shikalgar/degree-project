package com.example.CompetitionEventManagementSystem.Fragment;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.CompetitionEventManagementSystem.Dashboard;
import com.example.CompetitionEventManagementSystem.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class FragmentAddCertificate extends Fragment {

    private static final int REQUEST_CODE_SELECT_PHOTOS = 1002;
    private static final int PICK_IMAGE = 1;
    private static final int PICK_PDF = 2;

    private ImageView imgView;
    private Uri imageUri;
    private Bitmap selectedImageBitmap;
    private Spinner spinnerevents;
    private EditText PRNNO;
    private ArrayList<String> eventNames;
    private ArrayList<String> eventIds;
    private ArrayAdapter<String> adapter;
    private Button uploadcertButton;
    private Button choosecerti, camera;
    private TextView fileNameTextView;
    private String pdfBase64;
    String username;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        eventNames = new ArrayList<>();
        eventIds = new ArrayList<>();

        // Get the arguments (passed from Fragment A)
        Bundle bundle = getArguments();
        if (bundle != null) {
            username = bundle.getString("UserName", " "); // Default if not found
            Log.d("FragmentB", "Username received: " + username);
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Add Certificate");
        View view = inflater.inflate(R.layout.fragment_add_certificate, container, false);

        // Initialize views
        fileNameTextView = view.findViewById(R.id.textView_file_name);
        PRNNO = view.findViewById(R.id.edittext_prn);
        spinnerevents = view.findViewById(R.id.spinner_event_name);
        uploadcertButton = view.findViewById(R.id.button_upload);
        imgView = view.findViewById(R.id.icon_upload);

        // Set up spinner
        adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, eventNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerevents.setAdapter(adapter);

        // Select photos button
        view.findViewById(R.id.button_choose_image).setOnClickListener(v ->

         selectImage());

        Button choosePdfButton = view.findViewById(R.id.button_choose_pdf);

        // Upload button
        uploadcertButton.setOnClickListener(v -> uploadFiles());

        // Choose PDF
        choosePdfButton.setOnClickListener(v ->
                selectPdf());
        // Fetch events for spinner
        fetchEvents();

        // Request permission if not granted
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_CODE_SELECT_PHOTOS);
        }
        return view;
    }

    private void fetchEvents() {
        String url = "http://www.testproject.info/CollageEventManagment/CollageEventMan_getEventNSpinner.php";
        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Loading events...");
        progressDialog.show();

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    progressDialog.dismiss();
                    try {
                        if (response.getString("status").equals("success")) {
                            JSONArray events = response.getJSONArray("event");
                            for (int i = 0; i < events.length(); i++) {
                                JSONObject event = events.getJSONObject(i);
                                eventNames.add(event.getString("name"));
                                eventIds.add(event.getString("id"));
                            }
                            adapter.notifyDataSetChanged();
                        } else {
                            Toast.makeText(getActivity(), "No events found", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getActivity(), "Error parsing events", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(), "Error fetching events", Toast.LENGTH_SHORT).show();
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(jsonObjectRequest);
    }

    private void selectImage() {
        // Reset the file name and image view when selecting a new image
        fileNameTextView.setText("");
        imgView.setImageResource(R.drawable.add_photo); // Set a default placeholder

        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_IMAGE);
    }

    private void selectPdf() {
        // Reset the file name when selecting a new PDF
        fileNameTextView.setText("");

        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("application/pdf");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_PDF);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == getActivity().RESULT_OK && data != null) {
            Uri uri = data.getData();
            String mimeType = getActivity().getContentResolver().getType(uri);

            // Get the file name from the URI
            String fileName = getFileName(uri);
            fileNameTextView.setText(fileName);  // Display the file name

            if (requestCode == PICK_IMAGE) {
                // Reset the PDF selection if an image is selected
                pdfBase64 = null;

                if (mimeType != null && mimeType.startsWith("image/")) {
                    imageUri = uri;
                    try {
                        selectedImageBitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);
                        imgView.setImageBitmap(selectedImageBitmap);
                    } catch (IOException e) {
                        e.printStackTrace();
                        Log.e("AddEqui", "Error loading image: " + e.getMessage());
                    }
                }
            } else if (requestCode == PICK_PDF) {
                // Reset the image selection if a PDF is selected
                selectedImageBitmap = null;

                if (mimeType != null && mimeType.equals("application/pdf")) {
                    try {
                        pdfBase64 = convertPdfToBase64(uri);  // Store the PDF Base64
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }


    private String getFileName(Uri uri) {
        String fileName = null;
        String[] projection = {MediaStore.Images.Media.DISPLAY_NAME};

        try (Cursor cursor = getActivity().getContentResolver().query(uri, projection, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
                fileName = cursor.getString(columnIndex);
            }
        }

        if (fileName == null) {
            fileName = uri.getLastPathSegment(); // fallback for file names without display name
        }

        return fileName;
    }

    private String convertPdfToBase64(Uri uri) throws IOException {
        InputStream inputStream = getActivity().getContentResolver().openInputStream(uri);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        byte[] buffer = new byte[1024];
        int length;
        while ((length = inputStream.read(buffer)) != -1) {
            byteArrayOutputStream.write(buffer, 0, length);
        }
        byte[] pdfBytes = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(pdfBytes, Base64.NO_WRAP); // Return the Base64 string for PDF
    }

    private void uploadFiles() {
        String SPRN = PRNNO.getText().toString().trim();
        String eventName = spinnerevents.getSelectedItem().toString();
        int selectedIndex = spinnerevents.getSelectedItemPosition();
        String eventId = eventIds.get(selectedIndex);  // Event ID

        if (SPRN.isEmpty() || eventName.isEmpty() || eventId.isEmpty() || (selectedImageBitmap == null && pdfBase64 == null)) {
            Toast.makeText(getContext(), "Please fill in all fields and select an image or PDF", Toast.LENGTH_SHORT).show();
            return;
        }

        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        String imageBase64 = selectedImageBitmap != null ? convertImageToBase64(selectedImageBitmap) : null;
        String pdfBase64Value = pdfBase64 != null ? pdfBase64 : null;

        uploadCertificateToServer(SPRN, eventName, eventId, imageBase64, pdfBase64Value, progressDialog);
    }

    private String convertImageToBase64(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] imageBytes = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.NO_WRAP); // Return the Base64 string for image
    }
    private void uploadCertificateToServer(String SPRN, String eventName, String eventId, String imageBase64, String pdfBase64, ProgressDialog progressDialog) {

        class AsyncTaskUploadClass extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                progressDialog.setMessage("Uploading Image and Data...");
                progressDialog.show();
            }

            @Override
            protected String doInBackground(Void... voids) {
                String serverUploadUrl = "http://tsm.ecssofttech.com/CompetitionEventManS_AddCertificate_new.php";
                imageProcessClass imageProcessClass = new imageProcessClass();

                // Initialize HashMap to store the data
                HashMap<String, String> postData = new HashMap<>();
                postData.put("PRNNo", SPRN);
                postData.put("Ename", eventName);
                postData.put("EID", eventId);

                // Ensure that imageBase64 and pdfBase64 are not null and check if both are provided
                boolean isImageEmpty = imageBase64 == null || imageBase64.isEmpty();
                boolean isPdfEmpty = pdfBase64 == null || pdfBase64.isEmpty();

                // Check if both Image and PDF are provided
                if (!isImageEmpty && !isPdfEmpty) {
                    // If both are provided, return an error message
                    return "{\"status\":\"failure\",\"message\":\"You can upload only one file at a time: either an image or a PDF.\"}";
                }

                // Add only one of the fields, depending on what's provided
                if (!isImageEmpty) {
                    postData.put("Image", imageBase64);
                    postData.put("pdf", "");  // Ensure pdf is not sent
                } else if (!isPdfEmpty) {
                    postData.put("Image", "");  // Ensure Image is not sent
                    postData.put("pdf", pdfBase64);
                } else {
                    // If neither is provided, return an error message
                    return "{\"status\":\"failure\",\"message\":\"Missing required parameters (Image or PDF)\"}";
                }

                // Call the ImageHttpRequest method and return the response
                return imageProcessClass.ImageHttpRequest(serverUploadUrl, postData);
            }


            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);
                progressDialog.dismiss();

                Log.d("Server Response", result);  // Log the full response for debugging

                if (result.startsWith("<html>")) {
                    // This indicates an HTML error page is returned
                    Toast.makeText(getActivity(), "Unexpected server error: Please try again later.", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        // Try to parse the response as JSON
                        JSONObject jsonResponse = new JSONObject(result);

                        // Get status and message from the response
                        String status = jsonResponse.getString("status");
                        String message = jsonResponse.getString("message");

                        if ("success".equals(status)) {
                            // Handle success case
                            showSuccessDialog(message);
                        } else {
                            // Handle failure case
                            Toast.makeText(getActivity(), "Failed to add certificate: " + message, Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        // Handle JSON parsing error
                        Toast.makeText(getActivity(), "Error parsing response: " + result, Toast.LENGTH_SHORT).show();
                    }
                }
            }


        }
            // Execute the AsyncTask
        AsyncTaskUploadClass asyncTask = new AsyncTaskUploadClass();
        asyncTask.execute();
    }


    private void showSuccessDialog(String message) {

        new androidx.appcompat.app.AlertDialog.Builder(getContext())
                .setTitle("Certificate Added Successfully")
                .setMessage("The Certificate has been added.")
                .setPositiveButton("OK", (dialog, which) -> {
                    // Create an Intent to start the Dashboard activity
                    Intent intent = new Intent(getActivity(), Dashboard.class);

                    // Pass the username as an extra
                    intent.putExtra("UserName", username);

                    // Start the Dashboard activity
                    startActivity(intent);

                    // Finish the current activity or fragment
                    getActivity().finishAffinity();
                })
                .setCancelable(false)
                .show();
    }

    public class imageProcessClass {

        public String ImageHttpRequest(String requestURL, HashMap<String, String> postData) {
            StringBuilder stringBuilder = new StringBuilder();

            try {
                URL url = new URL(requestURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setReadTimeout(19000);
                httpURLConnection.setConnectTimeout(19000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.setDoOutput(true);

                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                bufferedWriter.write(getPostDataString(postData));
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                int responseCode = httpURLConnection.getResponseCode();
                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line);
                    }
                    bufferedReader.close();

                    // Log the raw response to check for any unexpected content
                    Log.d("Response", stringBuilder.toString());

                    // Ensure the response is in JSON format
                    String contentType = httpURLConnection.getHeaderField("Content-Type");
                    if (contentType != null && contentType.contains("application/json")) {
                        try {
                            // Parse the JSON response
                            JSONObject jsonResponse = new JSONObject(stringBuilder.toString());
                            return jsonResponse.toString(); // or handle the JSON data as needed
                        } catch (JSONException e) {
                            Log.e("JSON Error", "Error parsing JSON: " + e.getMessage());
                            return "JSON parse error: " + e.getMessage();
                        }
                    } else {
                        return "Expected JSON but received: " + contentType;
                    }
                } else {
                    return "Error: " + responseCode;
                }

            } catch (IOException e) {
                e.printStackTrace();
                return "IOException: " + e.getMessage();
            }


        }

        private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
            StringBuilder result = new StringBuilder();

            for (Map.Entry<String, String> entry : params.entrySet()) {
                // Check for null or empty values before encoding
                if (entry.getValue() != null && !entry.getValue().isEmpty()) {
                    if (result.length() > 0) result.append("&");
                    result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                    result.append("=");
                    result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
                } else {
                    // Log if the value is null or empty
                    Log.e("Error", "Null or empty value for key: " + entry.getKey());
                }
            }

            return result.toString();
        }

}
}
