package com.example.CompetitionEventManagementSystem.Fragment;


import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.fragment.app.Fragment;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.CompetitionEventManagementSystem.PaymentGatewayAdapter;
import com.example.CompetitionEventManagementSystem.R;
import com.example.CompetitionEventManagementSystem.StudentDashboard;
import com.payu.base.models.CustomNote;
import com.payu.base.models.ErrorResponse;
import com.payu.base.models.PayUPaymentParams;
import com.payu.base.models.PayUSIParams;
import com.payu.base.models.PaymentMode;
import com.payu.base.models.PaymentType;
import com.payu.checkoutpro.PayUCheckoutPro;
import com.payu.checkoutpro.models.PayUCheckoutProConfig;
import com.payu.checkoutpro.utils.PayUCheckoutProConstants;
import com.payu.ui.model.listeners.PayUCheckoutProListener;
import com.payu.ui.model.listeners.PayUHashGenerationListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.Key;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashMap;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class F_Student_RegEvent extends Fragment {

    private TextView nameTextView, categoryTextView, dateTextView, timeTextView, eventFeeTextView;
    private EditText studentNameEditText, phoneEditText, prnEditText;
    private Spinner genderSpinner;

    private String eventName, eventCategory, eventDate, eventTime, eventFee;

    private final String email = "snooze@payu.in";
    private final String phone = "9999999999";
    private final String merchantName = "RH Group";
    private final String surl = "https://payuresponse.firebaseapp.com/success";
    private final String furl = "https://payuresponse.firebaseapp.com/failure";
    private final String amount = "1.0";
    private final String testKey = "IUIaFM";
    private final String testSalt = "<Please_add_salt_here>";
    private final String prodKey = "4rSUUA";
    private final String prodSalt = "UOssuafMZyn3LqkKnCwKyGBLG94uY6kj";
    private long mLastClickTime;
    private final String testMerchantAccessKey = "<Please_add_your_merchant_access_key>";
    private final String testMerchantSecretKey = "<Please_add_your_merchant_secret_key>";
    private PaymentGatewayAdapter reviewOrderAdapter;


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().setTitle("Register In Event");

        View view = inflater.inflate(R.layout.fragment_f__student__reg_event, container, false);

        nameTextView = view.findViewById(R.id.event_name);
        categoryTextView = view.findViewById(R.id.event_category);
        dateTextView = view.findViewById(R.id.event_date);
        timeTextView = view.findViewById(R.id.event_time);
        eventFeeTextView = view.findViewById(R.id.event_fee);
        studentNameEditText = view.findViewById(R.id.editTextText);
        phoneEditText = view.findViewById(R.id.phone);
        prnEditText = view.findViewById(R.id.prnno);
        genderSpinner = view.findViewById(R.id.gender);

        Bundle arguments = getArguments();
        if (arguments != null) {
            eventName = arguments.getString("eventName");
            eventCategory = arguments.getString("eventCategory");
            eventDate = arguments.getString("eventDate");
            eventTime = arguments.getString("eventTime");
            eventFee = arguments.getString("EntryFee");

            nameTextView.setText(eventName);
            categoryTextView.setText(eventCategory);
            dateTextView.setText(eventDate);
            timeTextView.setText(eventTime);
            eventFeeTextView.setText(eventFee);
        } else {
            Toast.makeText(getContext(), "Data not passed", Toast.LENGTH_SHORT).show();
        }

        view.findViewById(R.id.button).setOnClickListener(v ->  startPayment());

        return view;
    }

    private void startPayment() {

        // Preventing multiple clicks, using threshold of 1 second
        if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
            return;
        mLastClickTime = SystemClock.elapsedRealtime();
        initUiSdk(preparePayUBizParams());
    }

    private PayUPaymentParams preparePayUBizParams() {
        //String BuyerName = input_firstname.getText().toString() + " " + input_Middlename.getText().toString() + " " + input_Lastname.getText().toString();
        String BuyerName = "Shraddha Pravin Jangam ";

        String Email = "shraddhajangam2004@gmail.com";
        String Phone = "9359880155";
        /*String amount = input_Amount.getText().toString();*/
        /*String amount = "200";*/
        String amount = eventFeeTextView.getText().toString();
        String purpose = "App Memeber Registration";
        HashMap<String, Object> additionalParams = new HashMap<>();
        additionalParams.put(PayUCheckoutProConstants.CP_UDF1, "udf1");
        additionalParams.put(PayUCheckoutProConstants.CP_UDF2, "udf2");
        additionalParams.put(PayUCheckoutProConstants.CP_UDF3, "udf3");
        additionalParams.put(PayUCheckoutProConstants.CP_UDF4, "udf4");
        additionalParams.put(PayUCheckoutProConstants.CP_UDF5, "udf5");


        PayUSIParams siDetails = null;


        PayUPaymentParams.Builder builder = new PayUPaymentParams.Builder();
        builder.setAmount(amount)
                .setIsProduction(true)
                .setProductInfo(purpose)
                .setKey(prodKey)
                .setPhone(Phone)
                .setTransactionId(String.valueOf(System.currentTimeMillis()))
                .setFirstName(BuyerName)
                .setEmail(Email)
                .setSurl(surl)
                .setFurl(furl)
                .setUserCredential(prodKey + ":john@yopmail.com")
                .setAdditionalParams(additionalParams)
                .setPayUSIParams(siDetails);
        PayUPaymentParams payUPaymentParams = builder.build();
        return payUPaymentParams;
    }
    private void initUiSdk(PayUPaymentParams payUPaymentParams) {
        PayUCheckoutPro.open(
                getActivity(),
                payUPaymentParams,
                getCheckoutProConfig(),
                new PayUCheckoutProListener() {

                    @Override
                    public void onPaymentSuccess(Object response) {


                        try {
                            showAlertDialog(response);
                        } catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onPaymentFailure(Object response) {
                        try {
                            // failRegisterUser();
                        } catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onPaymentCancel(boolean isTxnInitiated) {
                        //  showSnackBar(getResources().getString(R.string.transaction_cancelled_by_user));
                        try {
                            // failRegisterUser();
                        } catch (Exception exception) {
                            exception.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ErrorResponse errorResponse) {
                        String errorMessage = errorResponse.getErrorMessage();
                        if (TextUtils.isEmpty(errorMessage))
                            // errorMessage = getResources().getString(R.string.some_error_occurred);
                            //  showSnackBar(errorMessage);
                            System.out.println("n");
                    }

                    @Override
                    public void setWebViewProperties(@Nullable WebView webView, @Nullable Object o) {
                        //For setting webview properties, if any. Check Customized Integration section for more details on this
                    }

                    @Override
                    public void generateHash(HashMap<String, String> valueMap, PayUHashGenerationListener hashGenerationListener) {
                        String hashName = valueMap.get(PayUCheckoutProConstants.CP_HASH_NAME);
                        String hashData = valueMap.get(PayUCheckoutProConstants.CP_HASH_STRING);
                        if (!TextUtils.isEmpty(hashName) && !TextUtils.isEmpty(hashData)) {
                            //Generate Hash from your backend here
                            String hash = null;
                            if (hashName.equalsIgnoreCase(PayUCheckoutProConstants.CP_LOOKUP_API_HASH)){
                                //Calculate HmacSHA1 HASH for calculating Lookup API Hash
                                ///Do not generate hash from local, it needs to be calculated from server side only. Here, hashString contains hash created from your server side.

                                hash = calculateHmacSHA1Hash(hashData, testMerchantSecretKey);
                            } else {

                                //Calculate SHA-512 Hash here
                                hash = calculateHash(hashData + prodSalt);
                            }

                            HashMap<String, String> dataMap = new HashMap<>();
                            dataMap.put(hashName, hash);
                            hashGenerationListener.onHashGenerated(dataMap);
                        }
                    }
                }
        );
    }

    private String calculateHash(String hashString) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
            messageDigest.update(hashString.getBytes());
            byte[] mdbytes = messageDigest.digest();
            return getHexString(mdbytes);
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }

    private String calculateHmacSHA1Hash(String data, String key) {
        String HMAC_SHA1_ALGORITHM = "HmacSHA1";
        String result = null;

        try {
            Key signingKey = new SecretKeySpec(key.getBytes(), HMAC_SHA1_ALGORITHM);
            Mac mac = Mac.getInstance(HMAC_SHA1_ALGORITHM);
            mac.init(signingKey);
            byte[] rawHmac = mac.doFinal(data.getBytes());
            result = getHexString(rawHmac);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    private String getHexString(byte[] array){
        StringBuilder hash = new StringBuilder();
        for (byte hashByte : array) {
            hash.append(Integer.toString((hashByte & 0xff) + 0x100, 16).substring(1));
        }
        return hash.toString();
    }

    private void showAlertDialog(Object response) throws JSONException {
        String me=null;
        String txnid=null;
        String id=null;
        HashMap<String,Object> result = (HashMap<String, Object>) response;
        try {


            JSONArray contacts = new JSONArray();
            try{
                JSONObject emp=(new JSONObject((String) result.get(PayUCheckoutProConstants.CP_PAYU_RESPONSE)));
                me=emp.getString("status");
                txnid=emp.getString("txnid");
                id=emp.getString("id");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            //   HashMap<String,Object> result = (HashMap<String, Object>) response;
            new AlertDialog.Builder(getContext())
                    .setCancelable(false)
                    .setMessage("Response"+me)



                    .setPositiveButton("Ok", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    }).show();

            if(me.equals("success"))
            {
                // add_data();
                //RegisterUser(id,txnid);
                handleRegistration();

            }else {
                //ailRegisterUser();
            }
        }
        catch (Exception ex)
        {}

    }

    private PayUCheckoutProConfig getCheckoutProConfig() {
        PayUCheckoutProConfig checkoutProConfig = new PayUCheckoutProConfig();
        checkoutProConfig.setPaymentModesOrder(getCheckoutOrderList());

//        checkoutProConfig.setEnforcePaymentList(getEnforcePaymentList());
        checkoutProConfig.setShowCbToolbar(false);
        checkoutProConfig.setAutoSelectOtp(true);
        checkoutProConfig.setAutoApprove(true);
        checkoutProConfig.setSurePayCount(Integer.parseInt("0"));
        checkoutProConfig.setShowExitConfirmationOnPaymentScreen(false);
        checkoutProConfig.setShowExitConfirmationOnCheckoutScreen(false);
        checkoutProConfig.setMerchantName("Travel Light");
        checkoutProConfig.setMerchantLogo(R.drawable.img2);
        checkoutProConfig.setWaitingTime(30000);
        checkoutProConfig.setMerchantResponseTimeout(30000);
        checkoutProConfig.setCustomNoteDetails(getCustomeNoteList());
        if (reviewOrderAdapter != null)
            checkoutProConfig.setCartDetails(reviewOrderAdapter.getOrderDetailsList());
        return checkoutProConfig;
    }

    public ArrayList<CustomNote> getCustomeNoteList() {
        ArrayList<CustomNote> customNote = new ArrayList<>();
        String str = "null";

        // Ensure `view` is correctly initialized in your Fragment
        if (getView() == null) {
            return customNote; // Return empty list if view is null
        }

        View view = getView();

        if (str.equals("null")) {
            ArrayList<PaymentType> noteCategory = new ArrayList<>();
            // Add PaymentType categories if needed
        } else if (((AppCompatSpinner) view.findViewById(R.id.et_custom_note_category_value))
                .getSelectedItem().toString().equalsIgnoreCase("NULL")) {

            String customNoteValue = ((EditText) view.findViewById(R.id.et_custom_note_value))
                    .getText().toString();

            CustomNote customNote1 = new CustomNote(customNoteValue, null);
            customNote1.setCustom_note(customNoteValue);
            customNote1.setCustom_note_category(null);
            customNote.add(customNote1);

        } else {
            ArrayList<PaymentType> noteCategory = new ArrayList<>();
            noteCategory.add(PaymentType.CARD);
            noteCategory.add(PaymentType.NB);
            noteCategory.add(PaymentType.UPI);
            noteCategory.add(PaymentType.WALLET);
            noteCategory.add(PaymentType.EMI);

            String customNoteValue = ((EditText) view.findViewById(R.id.et_custom_note_value))
                    .getText().toString();

            CustomNote customNote1 = new CustomNote(customNoteValue, noteCategory);
            customNote1.setCustom_note(customNoteValue);
            customNote1.setCustom_note_category(noteCategory);
            customNote.add(customNote1);
        }

        return customNote;
    }


    private ArrayList<PaymentMode> getCheckoutOrderList() {
        ArrayList<PaymentMode> checkoutOrderList = new ArrayList();

        checkoutOrderList.add(new PaymentMode(PaymentType.UPI, PayUCheckoutProConstants.CP_GOOGLE_PAY));

        checkoutOrderList.add(new PaymentMode(PaymentType.WALLET, PayUCheckoutProConstants.CP_PHONEPE));

        checkoutOrderList.add(new PaymentMode(PaymentType.WALLET, PayUCheckoutProConstants.CP_PAYTM));

        return checkoutOrderList;
    }


    private void handleRegistration() {
        String studentName = studentNameEditText.getText().toString().trim();
        String phoneNumber = phoneEditText.getText().toString().trim();
        String gender = genderSpinner.getSelectedItem().toString().trim();
        String prn = prnEditText.getText().toString().trim();

        if (studentName.isEmpty() || phoneNumber.isEmpty() || prn.isEmpty()) {
            Toast.makeText(getContext(), "Please fill all the fields", Toast.LENGTH_SHORT).show();
        }
        else if (phoneNumber.length() != 10 || !phoneNumber.matches("\\d+")) {
            Toast.makeText(getContext(), "Mobile number must be 10 digits", Toast.LENGTH_SHORT).show();
        }
        else if (prn.length() != 13 || !prn.matches("\\d+")) {
            Toast.makeText(getActivity(), "PRN Number must be 13 digits", Toast.LENGTH_SHORT).show();
        }
        else {
            showConfirmationDialog(studentName, phoneNumber, gender, prn);
        }
    }

    private void showConfirmationDialog(String studentName, String phoneNumber, String gender, String prn) {
        new androidx.appcompat.app.AlertDialog.Builder(getContext())
                .setTitle("Confirm Registration")
                .setMessage("Do you want to proceed with the payment of " + eventFee + " for registration?")
                .setPositiveButton("Confirm", (dialog, which) -> insertData(studentName, phoneNumber, gender, prn, eventName, eventCategory, eventDate, eventTime, eventFee))
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .setCancelable(false)
                .show();
    }

    private void insertData(String studentName, String phoneNumber, String gender, String prn, String eventName, String eventCategory, String eventDate, String eventTime, String eventFee) {
        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        String url = "http://www.testproject.info/CollageEventManagment/CompetitionEventManS_StuRegisterToEvent.php?SName=" + studentName +
                "&PhoneNumber=" + phoneNumber +
                "&Gender=" + gender +
                "&PRNNo=" + prn +
                "&EventName=" + eventName +
                "&EventCategory=" + eventCategory +
                "&EventDate=" + eventDate +
                "&EventTime=" + eventTime +
                "&EventFee=" + eventFee;

        StringRequest request = new StringRequest(Request.Method.GET, url, response -> {
            Log.e("response", response);
            if (response.equals("Inserted")) {
                showSuccessDialog(prn);
            } else {
                Toast.makeText(getActivity(), "Registration failed: " + response, Toast.LENGTH_SHORT).show();
            }
            progressDialog.dismiss();
        }, error -> {
            Toast.makeText(getActivity(), "Something went wrong. Try later.", Toast.LENGTH_SHORT).show();
            progressDialog.dismiss();
        });

        RequestQueue queue = Volley.newRequestQueue(getActivity());
        queue.add(request);
    }

    private void showSuccessDialog(String prnNo) {
        new androidx.appcompat.app.AlertDialog.Builder(getContext())
                .setTitle("Registration Successful")
                .setMessage("You are registered in the event successfully.")
                .setPositiveButton("OK", (dialog, which) -> {
                    Intent intent = new Intent(getActivity(), StudentDashboard.class);
                    intent.putExtra("PRNNo", prnNo); // Pass PRNNo
                    startActivity(intent);
                    getActivity().finishAffinity();
                })
                .setCancelable(false)
                .show();
    }

}
