package com.example.CompetitionEventManagementSystem.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.CompetitionEventManagementSystem.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class F_Myprofile extends Fragment {
    private String UN;
    private TextView fname, Email, Mobile,Password,Uname;
    private Button edit,bk;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Retrieve the mobile argument from the Bundle
        if (getArguments() != null) {
            UN = getArguments().getString("UserName");
            Log.d("Myprofile", "Mobile received: " + UN);
        } else {
            Log.d("Myprofile", "No mobile argument received.");
        }

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("My Profile");
        View view =  inflater.inflate(R.layout.fragment_f__myprofile, container, false);
        // Initialize TextViews
        fname = view.findViewById(R.id.Fname);
        Mobile = view.findViewById(R.id.mobile);
        Email = view.findViewById(R.id.Email);
        Uname = view.findViewById(R.id.UName);
        Password = view.findViewById(R.id.pass);

        bk = view.findViewById(R.id.back);
        bk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment homeFragment = new F_Home();
                getParentFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, homeFragment)
                        .addToBackStack(null)
                        .commit();
            }
        });

        // Fetch user data
        getData();


        return view;
    }

    private void getData() {

        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        // Fetch data from the server
        new Handler(Looper.getMainLooper()).post(() -> {
            SharedPreferences sharedPreferences = getActivity().getSharedPreferences("LoginData", Context.MODE_PRIVATE);
            String UN = sharedPreferences.getString("UserName", "");  // Retrieve Mobile

            // Define the URL for the GET request
            String url = "http://www.testproject.info/CollageEventManagment/CollageEventMan_Myprofile.php?UserName=" + UN;

            StringRequest request = new StringRequest(Request.Method.GET, url, response -> {
                Log.d("MyProfile", "Response: " + response);  // Log the raw response
                try {
//                    // Clean the response by removing HTML tags
//                    String cleanedResponse = response.replaceAll("<br>", "");

                    // Check if the cleaned response is a valid JSON array
                    JSONArray jsonArray = new JSONArray(response);

                    if (jsonArray.length() > 0) {
                        JSONObject jsonObject = jsonArray.getJSONObject(0);
//                        Log.d("UserProfile", "Parsed JSONObject: " + jsonObject.toString());  // Log the parsed JSONObject

                        // Extract data from the JSON object
                        String FN = jsonObject.getString("FName");
                        String Mob = jsonObject.getString("Mobile");
                        String Eml = jsonObject.getString("Email");
                        String UND = jsonObject.getString("UserName");
                        String Pass = jsonObject.getString("Password");

                        // Set the TextViews with the fetched data
                        fname.setText(FN);
                        Mobile.setText(Mob);
                        Email.setText(Eml);
                        Uname.setText(UND);
                        Password.setText(Pass);
                    } else {
                        Toast.makeText(getActivity(), "No data found", Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e) {
                    Log.e("MyProfile", "JSON Parsing error: " + e.getMessage(), e);
                    Toast.makeText(getActivity(), "Parsing error", Toast.LENGTH_SHORT).show();
                } finally {
                    progressDialog.dismiss();  // Dismiss the progress dialog
                }
            }, error -> {
                Log.e("MyProfile", "Volley error: " + error.getMessage(), error);
                Toast.makeText(getActivity(), "Technical error, try later..", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();  // Dismiss the progress dialog
            });

            // Add the request to the request queue
            RequestQueue queue = Volley.newRequestQueue(getActivity());
            queue.add(request);
        });
    }



}