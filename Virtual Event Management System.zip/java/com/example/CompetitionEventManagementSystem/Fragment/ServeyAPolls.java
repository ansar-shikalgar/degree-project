package com.example.CompetitionEventManagementSystem.Fragment;

import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.CompetitionEventManagementSystem.R;


public class ServeyAPolls extends Fragment {
    String mob;
    CardView cq, aq;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("Surveys & Polls");
        View view = inflater.inflate(R.layout.fragment_servey_a_polls, container, false);

        // Retrieve the mobile argument from the Bundle
        if (getArguments() != null) {
            mob = getArguments().getString("Mobile");
            Log.d("Student Certificate", "Mobile received: " + mob);
        } else {
            Log.d("Student Certificate", "No mobile argument received.");
        }

        cq = view.findViewById(R.id.ser);
        aq = view.findViewById(R.id.pol);

        // Click listener for "Create Question" (CQ)
        cq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFragment(new ServeyQueS(), mob);
            }
        });

        // Click listener for "All Questions" (AQ)
        aq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFragment(new PollQueS(), mob);
            }
        });


        return view;
    }

    // Method to replace current fragment with the new one and pass UserName
    private void openFragment(Fragment fragment, String userName) {
        Bundle bundle = new Bundle();
        bundle.putString("Mobile", userName);
        fragment.setArguments(bundle);

        FragmentTransaction transaction = requireActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}