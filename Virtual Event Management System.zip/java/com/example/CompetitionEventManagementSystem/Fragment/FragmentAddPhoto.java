package com.example.CompetitionEventManagementSystem.Fragment;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.CompetitionEventManagementSystem.Dashboard;
import com.example.CompetitionEventManagementSystem.ImageProcessClass;
import com.example.CompetitionEventManagementSystem.R;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class FragmentAddPhoto extends Fragment {

    private static final int REQUEST_CODE_SELECT_PHOTOS = 1002;
    private ArrayList<Uri> imageUris;
    private ImageView[] imageViews;
    private Spinner spinnerevents;
    private ArrayList<String> eventNames;
    private ArrayList<String> eventIds;
    private ArrayAdapter<String> adapter;
    private Button uploadPicButton;
    private Bitmap selectedImageBitmap;
    ImageView img1,img2,img3,img4;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imageUris = new ArrayList<>();
        eventNames = new ArrayList<>();
        eventIds = new ArrayList<>();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().setTitle("Add Picture");
        View view = inflater.inflate(R.layout.fragment_add_photo, container, false);

        // Initialize views
        img1 = view.findViewById(R.id.img1);
        img2 = view.findViewById(R.id.img2);
        img3 = view.findViewById(R.id.img3);
        img4 = view.findViewById(R.id.img4);
        imageViews = new ImageView[]{img1, img2, img3, img4};

        spinnerevents = view.findViewById(R.id.spinner_events);
        uploadPicButton = view.findViewById(R.id.btn_upload_photos);

        // Set up spinner
        adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, eventNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerevents.setAdapter(adapter);

        // Select photos button
        view.findViewById(R.id.btn_select_photos).setOnClickListener(v -> selectPhotos());

        // Upload button
        uploadPicButton.setOnClickListener(v -> uploadImages());

        // Fetch events for spinner
        fetchEvents();

        // Request permission if not granted
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_CODE_SELECT_PHOTOS);
        }
        return view;
    }

    private void selectPhotos() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(Intent.createChooser(intent, "Select up to 4 images"), REQUEST_CODE_SELECT_PHOTOS);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_SELECT_PHOTOS && resultCode == getActivity().RESULT_OK && data != null) {
            ClipData clipData = data.getClipData();
            if (clipData != null) {
                int availableSlots = 4 - imageUris.size();
                for (int i = 0; i < clipData.getItemCount() && availableSlots > 0; i++, availableSlots--) {
                    Uri imageUri = clipData.getItemAt(i).getUri();
                    addPhoto(imageUri);
                }
            } else if (data.getData() != null) {
                addPhoto(data.getData());
            } else {
                Toast.makeText(getActivity(), "No images selected.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void addPhoto(Uri uri) {
        if (imageUris.size() < 4) {
            imageUris.add(uri);
            displayPhoto(uri, imageUris.size() - 1);
        } else {
            Toast.makeText(getActivity(), "You can only select up to 4 images.", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayPhoto(Uri uri, int index) {
        if (index >= 0 && index < imageViews.length) {
            imageViews[index].setImageURI(uri);
        }
    }

    private void fetchEvents() {
        String url = "http://www.testproject.info/CollageEventManagment/CollageEventMan_getEventNSpinner.php";
        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Loading events...");
        progressDialog.show();

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    progressDialog.dismiss();
                    try {
                        if (response.getString("status").equals("success")) {
                            JSONArray events = response.getJSONArray("event");
                            for (int i = 0; i < events.length(); i++) {
                                JSONObject event = events.getJSONObject(i);
                                eventNames.add(event.getString("name"));
                                eventIds.add(event.getString("id"));
                            }
                            Log.d("fragment add photo","Event Name" +eventNames);
                            Log.d("fragment add photo","Event id" +eventIds);
                            adapter.notifyDataSetChanged();
                        } else {
                            Toast.makeText(getActivity(), "No events found", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getActivity(), "Error parsing events", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(), "Error fetching events", Toast.LENGTH_SHORT).show();
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(jsonObjectRequest);
    }

    private String convertImageToBase64(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(byteArray, Base64.DEFAULT);
    }

    private void uploadImages() {
        if (imageUris.isEmpty()) {
            Toast.makeText(getActivity(), "Please select images first.", Toast.LENGTH_SHORT).show();
            return;
        }

        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Uploading images...");
        progressDialog.show();

        // Convert images to Base64
        ArrayList<String> imageBase64List = new ArrayList<>();
        for (Uri uri : imageUris) {
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), uri);
                String imageBase64 = convertImageToBase64(bitmap);
                imageBase64List.add(imageBase64);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Prepare data for server
        HashMap<String, String> postData = new HashMap<>();
        String eventName = spinnerevents.getSelectedItem().toString();
        int selectedIndex = spinnerevents.getSelectedItemPosition();
        String eventId = eventIds.get(selectedIndex);  // Event ID

        postData.put("Ename", eventName);
        postData.put("EId", eventId);

        // Add image data to postData
        for (int i = 0; i < imageBase64List.size(); i++) {
            postData.put("Image" + (i + 1), imageBase64List.get(i));
        }

        // Create a request using ImageProcessClass
        ImageProcessClass imageProcessClass = new ImageProcessClass();

        imageProcessClass.ImageHttpRequest(
                "http://tsm.ecssofttech.com/CompetitionEventManS_AddPhotoNew.php", // Replace with your server URL
                postData,
                new ImageProcessClass.ImageHttpRequestListener() {
                    @Override
                    public void onResponseReceived(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            String message = jsonResponse.getString("message");

                            if ("success".equalsIgnoreCase(status)) {
                                Toast.makeText(getActivity(), "Upload Successful: " + message, Toast.LENGTH_SHORT).show();
                                showSuccessDialog();
                                // Log uploaded image paths if returned
                                if (jsonResponse.has("imageUrls")) {
                                    JSONObject imageUrls = jsonResponse.getJSONObject("imageUrls");
                                    Log.d("Image1 URL", imageUrls.optString("Image1", "No Image1"));
                                    Log.d("Image2 URL", imageUrls.optString("Image2", "No Image2"));
                                    Log.d("Image3 URL", imageUrls.optString("Image3", "No Image3"));
                                    Log.d("Image4 URL", imageUrls.optString("Image4", "No Image4"));
                                }
                            } else {
                                Toast.makeText(getActivity(), "Upload Failed: " + message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getActivity(), "Response Parsing Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onErrorReceived(String error) {
                        progressDialog.dismiss();
                        Toast.makeText(getActivity(), "Error: " + error, Toast.LENGTH_SHORT).show();
                        Log.d("postData", "Data sent: " + postData.toString());
                    }
                });
    }

    private void showSuccessDialog() {
 new androidx.appcompat.app.AlertDialog.Builder(getContext())
                .setTitle("Event Photo Added Successfully")
                .setMessage("The Event Photo  been added.")
                .setPositiveButton("OK", (dialog, which) -> {
                    startActivity(new Intent(getActivity(), Dashboard.class));
                    getActivity().finishAffinity();
                })
                .setCancelable(false)
                .show();
    }

}
