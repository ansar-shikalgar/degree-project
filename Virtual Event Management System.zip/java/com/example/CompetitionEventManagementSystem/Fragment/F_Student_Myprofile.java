package com.example.CompetitionEventManagementSystem.Fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.CompetitionEventManagementSystem.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class F_Student_Myprofile extends Fragment {
    private String mob;
    private TextView name, PRN, mobile, email, branch, Class;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Retrieve the mobile argument from the Bundle
        if (getArguments() != null) {
            mob = getArguments().getString("Mobile");
            Log.d("Student Myprofile", "Mobile received: " + mob);
        } else {
            Log.d("Student Myprofile", "No mobile argument received.");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
       getActivity().setTitle("My Profile");
        View view =  inflater.inflate(R.layout.fragment_f__student__myprofile, container, false);

        // Initialize TextViews
        name = view.findViewById(R.id.Fname);
        PRN = view.findViewById(R.id.PRNno);
        mobile = view.findViewById(R.id.mobile);
        email = view.findViewById(R.id.Email);
        branch = view.findViewById(R.id.branch);
        Class = view.findViewById(R.id.cla);

        // Fetch user data
        getData();


        return view;
    }

    private void getData() {

        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        // Fetch data from the server
        new Handler(Looper.getMainLooper()).post(() -> {
            SharedPreferences sharedPreferences = getActivity().getSharedPreferences("LoginData", Context.MODE_PRIVATE);
            String mob = sharedPreferences.getString("Mobile", "");  // Retrieve Mobile

            // Define the URL for the GET request
            String url = "http://www.testproject.info/CollageEventManagment/CompetitionEventManS_StudentMyProfile.php?Mobile=" + mob;

            StringRequest request = new StringRequest(Request.Method.GET, url, response -> {
                Log.d("MyProfile", "Response: " + response);  // Log the raw response
                try {
//                    // Clean the response by removing HTML tags
//                    String cleanedResponse = response.replaceAll("<br>", "");

                    // Check if the cleaned response is a valid JSON array
                    JSONArray jsonArray = new JSONArray(response);

                    if (jsonArray.length() > 0) {
                        JSONObject jsonObject = jsonArray.getJSONObject(0);
//                        Log.d("UserProfile", "Parsed JSONObject: " + jsonObject.toString());  // Log the parsed JSONObject

                        // Extract data from the JSON object
                        String FN = jsonObject.getString("FName");
                        String PRNN = jsonObject.getString("PRNNo");
                        String Mb = jsonObject.getString("Mobile");
                        String EL = jsonObject.getString("Email");
                        String Bc = jsonObject.getString("Branch");
                        String Cla = jsonObject.getString("Class");

                        // Set the TextViews with the fetched data
                        name.setText(FN);
                        PRN.setText(PRNN);
                        mobile.setText(Mb);
                        email.setText(EL);
                        branch.setText(Bc);
                        Class.setText(Cla);
                    } else {
                        Toast.makeText(getActivity(), "No data found", Toast.LENGTH_SHORT).show();
                    }

                } catch (JSONException e) {
                    Log.e("MyProfile", "JSON Parsing error: " + e.getMessage(), e);
                    Toast.makeText(getActivity(), "Parsing error", Toast.LENGTH_SHORT).show();
                } finally {
                    progressDialog.dismiss();  // Dismiss the progress dialog
                }
            }, error -> {
                Log.e("MyProfile", "Volley error: " + error.getMessage(), error);
                Toast.makeText(getActivity(), "Technical error, try later..", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();  // Dismiss the progress dialog
            });

            // Add the request to the request queue
            RequestQueue queue = Volley.newRequestQueue(getActivity());
            queue.add(request);
        });

    }
}