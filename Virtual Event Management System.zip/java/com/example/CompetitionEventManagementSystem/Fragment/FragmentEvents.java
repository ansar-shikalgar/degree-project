package com.example.CompetitionEventManagementSystem.Fragment;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.CompetitionEventManagementSystem.Adapter.AdapterAllEvents;
import com.example.CompetitionEventManagementSystem.Adapter.AdapterViewEvent;
import com.example.CompetitionEventManagementSystem.Model.ModelViewEvent;
import com.example.CompetitionEventManagementSystem.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class FragmentEvents extends Fragment {
    private RecyclerView recyclerView;
    private AdapterAllEvents adapterAllEvents;
    private List<ModelViewEvent> eventList;
    private ProgressBar progressBar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        getActivity().setTitle("All Events");
        View view = inflater.inflate(R.layout.fragment_events, container, false);

        recyclerView = view.findViewById(R.id.recview);
        progressBar = view.findViewById(R.id.dynamicProgressBar);

        // Initialize data list and set RecyclerView
        eventList = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Fetch data from API
        geteventData();

        return view;
    }

    private void geteventData() {

        // Show progress bar before starting data fetch
        progressBar.setVisibility(View.VISIBLE);

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("http://www.testproject.info/CollageEventManagment/CompetitionEventManS_getEventDataNew.php") // API endpoint
                .build();

        // Create a new thread to fetch data (to avoid blocking UI thread)
        new Thread(() -> {
            List<ModelViewEvent> list = new ArrayList<>();
            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    Log.e("API_ERROR", "Response failed: " + response.code());
                    return;
                }

                String responseBody = response.body().string();
                Log.d("API_RESPONSE", responseBody);

                // Parse the JSON array response
                JSONArray jsonArray = new JSONArray(responseBody);

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);

                    ModelViewEvent event = new ModelViewEvent();

                    event.setEventName(jsonObject.optString("Ename", "Unknown"));
                    event.setEventCategory(jsonObject.optString("ECategory", "Unknown"));
                    event.setEventDate(jsonObject.optString("Date", "Unknown"));
                    event.setEventTime(jsonObject.optString("Time", "Unknown"));
                    event.setEventFee(jsonObject.optString("EntryFee", "Unknown"));
                    event.setimgpath(jsonObject.optString("Imgpath", "")); // Set Imgpath

                    list.add(event);
                }
            } catch (JSONException | IOException e) {
                Log.e("API_ERROR", "Error: " + e.getMessage(), e);
            }

            // Update the RecyclerView on the main thread
            getActivity().runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);

                if (list.isEmpty()) {
                    Toast.makeText(getContext(), "No Event data available", Toast.LENGTH_SHORT).show();
                } else {
                    eventList = list;
                    // Initialize adapter with the fetched data
                    adapterAllEvents = new AdapterAllEvents(getContext(), eventList);
                    recyclerView.setAdapter(adapterAllEvents);
                }
            });
        }).start();

    }
}