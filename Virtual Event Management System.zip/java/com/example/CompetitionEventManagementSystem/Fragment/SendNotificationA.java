package com.example.CompetitionEventManagementSystem.Fragment;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.CompetitionEventManagementSystem.Dashboard;
import com.example.CompetitionEventManagementSystem.R;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class SendNotificationA extends Fragment {

    String UserName;
    EditText notify;
    ProgressDialog progressDialog;
    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().setTitle("Send Notification");
        View view = inflater.inflate(R.layout.fragment_send_notification_a, container, false);

        // Retrieve the Username argument from the Bundle
        if (getArguments() != null) {
            UserName = getArguments().getString("UserName");
            Log.d("SendNotification", "Mobile received: " + UserName);
        } else {
            Log.d("SendNotification", "No mobile argument received.");
        }

        notify = view.findViewById(R.id.etMessage);

        Button sendNotificationButton = view.findViewById(R.id.btnSendNotification);

        // Check and request SMS permission
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }

        sendNotificationButton.setOnClickListener(v -> {
            String msg = notify.getText().toString().trim();

            if (msg.isEmpty()) {
                Toast.makeText(getContext(), "Type Notification", Toast.LENGTH_SHORT).show();
            } else {
                getNumber(msg,UserName);  // Fetch numbers & send SMS
            }
        });

        return view;
    }

    // Handle SMS permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getContext(), "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "SMS Permission Denied. Enable it in Settings!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Fetch mobile numbers from MySQL Database
    private void getNumber(String msg, String userName) {
        String API_URL = "http://www.testproject.info/CollageEventManagment/CompetitionEventManS_getStudentNumber.php";

        ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Fetching Numbers...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, API_URL,
                response -> {
                    progressDialog.dismiss();
                    try {
                        JSONArray jsonArray = new JSONArray(response);
                        List<String> phoneNumbers = new ArrayList<>();

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            phoneNumbers.add(jsonObject.getString("Mobile"));
                        }

                        // Send SMS & Save Notification
                        for (String number : phoneNumbers) {
                            sendNotification(number, msg);
                        }

                        // Save Notification (Only Once)
                        sendNotificationToDatabase(msg, userName);

                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(getActivity(), "Error parsing data!", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(), "Error fetching numbers", Toast.LENGTH_SHORT).show();
                });

        queue.add(stringRequest);
    }

    // Send SMS Notification
    private void sendNotification(String mobileNumber, String message) {
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(mobileNumber, null, message, null, null);

                // Show Toast on Main Thread
                getActivity().runOnUiThread(() ->
                        Toast.makeText(getContext(), "SMS Sent to " + mobileNumber, Toast.LENGTH_SHORT).show()
                );

            } catch (Exception e) {
                e.printStackTrace();
                getActivity().runOnUiThread(() ->
                        Toast.makeText(getContext(), "Failed to send SMS", Toast.LENGTH_SHORT).show()
                );
            }
        } else {
            Toast.makeText(getContext(), "SMS Permission Not Granted!", Toast.LENGTH_SHORT).show();
        }
    }

    // Save Notification to Database using GET request
    private void sendNotificationToDatabase(String msg, String userName) {
        String baseUrl = "http://www.testproject.info/CollageEventManagment/CompetativeEventM_SendNotification.php";

        // Encode parameters to be URL safe
        try {
            userName = URLEncoder.encode(userName, "UTF-8");
            msg = URLEncoder.encode(msg, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        // Append parameters to the URL
        String API_URL = baseUrl + "?Notification=" + msg + "&Username=" + userName;

        RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest getRequest = new StringRequest(Request.Method.GET, API_URL,
                response -> {
                    if (response.trim().equalsIgnoreCase("Inserted")) {
                        Toast.makeText(getContext(), "Notification Saved!", Toast.LENGTH_SHORT).show();
                        showSuccessDialog(UserName);
                    } else if (response.contains("Error")) {
                        Toast.makeText(getContext(), "Failed: " + response, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Unexpected Response: " + response, Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Toast.makeText(getContext(), "Failed to connect!", Toast.LENGTH_SHORT).show();
                });

        queue.add(getRequest);
    }

    private void showSuccessDialog(String userName) {
        new androidx.appcompat.app.AlertDialog.Builder(getContext())
                .setTitle("Success")
                .setMessage("Msg Send Successfully!")
                .setCancelable(false)
                .setPositiveButton("OK", (dialog, which) -> {
                    // Navigate to Dashboard Activity and pass username
                    Intent intent = new Intent(getActivity(), Dashboard.class); // Replace 'Dashboard.class' with your actual activity class name
                    intent.putExtra("UserName", userName);
                    startActivity(intent);
                    getActivity().finish(); // Optional: close current activity/fragment host if needed
                })
                .show();
    }

}
