package com.example.CompetitionEventManagementSystem.Fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.CompetitionEventManagementSystem.R;
import com.example.CompetitionEventManagementSystem.StudentDashboard;


public class F_SurveySubmitted extends Fragment {
    String mobile;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
      getActivity().setTitle("Survey Submitted");
        View view = inflater.inflate(R.layout.fragment_f__survey_submitted, container, false);

         mobile = null;
        if (getArguments() != null) {
            mobile = getArguments().getString("Mobile");
            Log.d("F_SurveySubmitted", "Mobile received: " + mobile);
        }
        Button continueBtn = view.findViewById(R.id.btn_continue);
        continueBtn.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), StudentDashboard.class);
            intent.putExtra("Mobile", mobile);
            startActivity(intent);
            requireActivity().finish();
        });

        return view;
    }
}