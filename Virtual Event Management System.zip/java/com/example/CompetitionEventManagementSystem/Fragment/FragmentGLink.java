package com.example.CompetitionEventManagementSystem.Fragment;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.CompetitionEventManagementSystem.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;

public class FragmentGLink extends Fragment {
    String UserName;
    TextView Link, eventDateText;
    Button GLink, SendLink;
    Spinner spinnerevents;

    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    private ArrayList<String> eventNames;
    private ArrayList<String> eventIds;
    private ArrayAdapter<String> adapter;

    private String Event_ID = "", EventName = "";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().setTitle("Generate Link");
        View view = inflater.inflate(R.layout.fragment_g_link, container, false);

        if (getArguments() != null) {
            UserName = getArguments().getString("UserName");
            Log.d("FragmentGLink","UserName"+UserName);
        }

        spinnerevents = view.findViewById(R.id.spinner_events);
        eventDateText = view.findViewById(R.id.EDate);
        Link = view.findViewById(R.id.etPollQuestion);
        GLink = view.findViewById(R.id.btnGL);
        SendLink = view.findViewById(R.id.btnSubmit);

        GLink.setOnClickListener(v -> GenerateLink());
        SendLink.setOnClickListener(v -> SaveData(UserName));

        eventNames = new ArrayList<>();
        eventIds = new ArrayList<>();
        adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, eventNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerevents.setAdapter(adapter);

        fetchEvents();

        spinnerevents.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Event_ID = eventIds.get(position);
                EventName = eventNames.get(position);
                fetchEventDate(Event_ID);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                eventDateText.setText("");
            }
        });

        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }

        return view;
    }

    private void fetchEvents() {
        String url = "http://www.testproject.info/CollageEventManagment/CollageEventMan_getEventNSpinner.php";
        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Loading events...");
        progressDialog.show();

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    progressDialog.dismiss();
                    try {
                        if (response.getString("status").equals("success")) {
                            JSONArray events = response.getJSONArray("event");
                            for (int i = 0; i < events.length(); i++) {
                                JSONObject event = events.getJSONObject(i);
                                eventNames.add(event.getString("name"));
                                eventIds.add(event.getString("id"));
                            }
                            adapter.notifyDataSetChanged();
                        } else {
                            Toast.makeText(getActivity(), "No events found", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getActivity(), "Error parsing events", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(), "Error fetching events", Toast.LENGTH_SHORT).show();
                });

        Volley.newRequestQueue(getActivity()).add(jsonObjectRequest);
    }

    private void fetchEventDate(String eventId) {
        String url = "http://www.testproject.info/CollageEventManagment/CompetitionEventManS_getEventDateById.php?Id=" + eventId;

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        if (response.getString("status").equals("success")) {
                            String date = response.getString("date");
                            eventDateText.setText(date);
                        } else {
                            eventDateText.setText("Date not found");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        eventDateText.setText("Error parsing date");
                    }
                },
                error -> eventDateText.setText("Error fetching date"));

        Volley.newRequestQueue(getContext()).add(jsonObjectRequest);
    }

    private void GenerateLink() {
        String apiUrl = "http://work.ecssofttech.com/testwhereby.php";
        ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Generating link...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, apiUrl,
                response -> {
                    progressDialog.dismiss();
                    if (response != null && response.startsWith("https://")) {
                        Link.setText(response);
                        Toast.makeText(getActivity(), "Link Generated", Toast.LENGTH_SHORT).show();
                    } else {
                        Link.setText("Failed to generate link");
                        Toast.makeText(getActivity(), "Invalid response", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressDialog.dismiss();
                    Link.setText("Error generating link");
                    Toast.makeText(getActivity(), "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                });

        Volley.newRequestQueue(getActivity()).add(stringRequest);
    }

    private void SaveData(String userName) {
        String link = Link.getText().toString().trim();
        String date = eventDateText.getText().toString().trim();

        if (link.isEmpty() || date.isEmpty()) {
            Toast.makeText(getContext(), "Link or date cannot be empty!", Toast.LENGTH_SHORT).show();
        } else {
            getNumber(link, date, userName);
        }
    }

    private void getNumber(String link, String date, String userName) {
        String API_URL = "http://www.testproject.info/CollageEventManagment/CompetitionEventManS_getStudentNumber.php";
        ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Fetching Numbers...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, API_URL,
                response -> {
                    progressDialog.dismiss();
                    try {
                        JSONArray jsonArray = new JSONArray(response);
                        List<String> phoneNumbers = new ArrayList<>();

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            phoneNumbers.add(jsonObject.getString("Mobile"));
                        }

                        for (String number : phoneNumbers) {
                            sendSMS(number, link, date);
                        }

                        // Save Notification once
                        sendNotificationToDatabase(Event_ID, EventName, date, link, userName);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(getActivity(), "Error parsing data!", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    progressDialog.dismiss();
                    Toast.makeText(getActivity(), "Error fetching numbers", Toast.LENGTH_SHORT).show();
                });

        Volley.newRequestQueue(getContext()).add(stringRequest);
    }

    private void sendSMS(String number, String link, String date) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            String message = "Your Event is scheduled on " + date + ". Join Link: " + link;
            smsManager.sendTextMessage(number, null, message, null, null);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Failed to send SMS to " + number, Toast.LENGTH_SHORT).show();
        }
    }

    private void sendNotificationToDatabase(String eventId, String eventName, String date, String link, String userName) {
        try {
            String url = "http://www.testproject.info/CollageEventManagment/CompetitionEventManS_SaveLink.php";

            StringRequest request = new StringRequest(Request.Method.POST, url,
                    response -> {
                        Log.d("Response", response);
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String status = jsonObject.getString("status");
                            String message = jsonObject.getString("message");

                            if ("success".equals(status)) {
                                Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(getContext(), "Failed: " + message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getContext(), "Invalid response", Toast.LENGTH_SHORT).show();
                        }
                    },
                    error -> {
                        Log.e("VolleyError", error.toString());
                        Toast.makeText(getContext(), "Network error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Event_ID", eventId);
                    params.put("Event_Name", eventName);
                    params.put("EventDate", date);
                    params.put("Link", link);
                    params.put("Event_GUserN", userName);
                    return params;
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("User-Agent", "Mozilla/5.0");
                    return headers;
                }
            };

            Volley.newRequestQueue(getContext()).add(request);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "Error sending notification", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getContext(), "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "SMS Permission Denied!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
