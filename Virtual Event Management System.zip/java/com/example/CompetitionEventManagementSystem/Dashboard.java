package com.example.CompetitionEventManagementSystem;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.CompetitionEventManagementSystem.Fragment.F_Addevent;
import com.example.CompetitionEventManagementSystem.Fragment.F_Home;
import com.example.CompetitionEventManagementSystem.Fragment.F_Myprofile;
import com.example.CompetitionEventManagementSystem.Fragment.FragmentAddCertificate;
import com.example.CompetitionEventManagementSystem.Fragment.FragmentAddPhoto;
import com.example.CompetitionEventManagementSystem.Fragment.FragmentEvents;
import com.example.CompetitionEventManagementSystem.Fragment.FragmentGLink;
import com.example.CompetitionEventManagementSystem.Fragment.PollQuestions;
import com.example.CompetitionEventManagementSystem.Fragment.SendNotificationA;
import com.example.CompetitionEventManagementSystem.R;
import com.google.android.material.navigation.NavigationView;

public class Dashboard extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    private String Username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.tool1);
        setSupportActionBar(toolbar);

        // Setup Navigation Drawer
        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);  // Implemented listener

        // Setup ActionBarDrawerToggle
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Get the mobile number from the intent
        Intent intent = getIntent();
        Username = intent.getStringExtra("UserName");

        if (Username != null) {
            Log.d("Dashboard", "UserName: " + Username);
        } else {
            Log.d("Dashboard", "UserName is null");
        }

        // Load Home fragment initially if no fragment is loaded
        if (savedInstanceState == null) {
            loadHomeFragment();
        }
    }

    private void loadHomeFragment() {
        Bundle bundle = new Bundle();
        bundle.putString("UserName", Username);
        F_Home home = new F_Home();
        home.setArguments(bundle);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, home)
                .commit();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        // Handle fragment switching based on menu item clicks
        if (id == R.id.nav_dashboard) {
            // Load Home fragment
            loadHomeFragment();
        }
        else if (id == R.id.nav_addEvent) {
            // Load AddEvent fragment
            F_Addevent addEvent = new F_Addevent();
            Bundle bundle = new Bundle();
            bundle.putString("UserName", Username);
            addEvent.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, addEvent)
                    .addToBackStack(null)  // Add to back stack
                    .commit();
        }
        else if (id == R.id.nav_showE) {
            // Load AddEvent fragment
            FragmentEvents SEvent = new FragmentEvents();
            Bundle bundle = new Bundle();
            bundle.putString("UserName", Username);
            SEvent.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, SEvent)
                    .addToBackStack(null)  // Add to back stack
                    .commit();
        }
        else if (id == R.id.nav_GLink) {
            // Load AddEvent fragment
            FragmentGLink GEvent = new FragmentGLink();
            Bundle bundle = new Bundle();
            bundle.putString("UserName", Username);
            GEvent.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, GEvent)
                    .addToBackStack(null)  // Add to back stack
                    .commit();
        }
        else if (id == R.id.nav_addPhoto) {
            // Load AddEvent fragment
            FragmentAddPhoto addpic = new FragmentAddPhoto();
            Bundle bundle = new Bundle();
            bundle.putString("UserName", Username);
            addpic.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, addpic)
                    .addToBackStack(null)  // Add to back stack
                    .commit();
        }
        else if (id == R.id.nav_addCertificate) {
            // Load AddEvent fragment
            FragmentAddCertificate addCert = new FragmentAddCertificate();
            Bundle bundle = new Bundle();
            bundle.putString("UserName", Username);
            addCert.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, addCert)
                    .addToBackStack(null)  // Add to back stack
                    .commit();
        }
        else if (id == R.id.nav_sendNotication) {
            // Load AddEvent fragment
            SendNotificationA sN = new SendNotificationA();
            Bundle bundle = new Bundle();
            bundle.putString("UserName", Username);
            sN.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, sN)
                    .addToBackStack(null)  // Add to back stack
                    .commit();
        }
        else if (id == R.id.nav_CQue) {
            // Load AddEvent fragment
            PollQuestions sN = new PollQuestions();
            Bundle bundle = new Bundle();
            bundle.putString("UserName", Username);
            sN.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, sN)
                    .addToBackStack(null)  // Add to back stack
                    .commit();
        }
        else if (id == R.id.nav_Profile) {
            // Load MyProfile fragment
            F_Myprofile myProfile = new F_Myprofile();
            Bundle bundle = new Bundle();
            bundle.putString("UserName", Username);
            myProfile.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, myProfile)
                    .addToBackStack(null)  // Add to back stack
                    .commit();
        }
        else if (id == R.id.logOut) {
            // Clear login session and navigate to the Login screen
            SharedPreferences sharedPreferences = getSharedPreferences("LoginData", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear();  // Clear all saved data
            editor.apply();

            Intent logoutIntent = new Intent(Dashboard.this, Login.class);
            logoutIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(logoutIntent);
            finish();  // Finish current activity to prevent going back to it
        }
        // Close the drawer after selection
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        // Close the navigation drawer if it is open
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();  // Call default back press behavior
        }
    }
}
