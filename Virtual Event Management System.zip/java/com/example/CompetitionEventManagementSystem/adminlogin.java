package com.example.CompetitionEventManagementSystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class adminlogin extends AppCompatActivity {
Button log,reg;
EditText username,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_adminlogin);
        log=findViewById(R.id.adminlog);

        username=findViewById(R.id.adminusername);
        password=findViewById(R.id.adminpassword);
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(username.getText().toString().equals("admin")&&password.getText().toString().equals("admin")){
                    Toast.makeText(adminlogin.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(adminlogin.this, Admindashboard.class);
                    startActivity(intent);
                    finishAffinity();
                }
                else {
                    Toast.makeText(adminlogin.this, "Login Failed:Username or Password is Incorrect", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}