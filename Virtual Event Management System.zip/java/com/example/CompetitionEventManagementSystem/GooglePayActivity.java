package com.example.CompetitionEventManagementSystem;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.Key;
import java.security.MessageDigest;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import okhttp3.Response;

import com.payu.base.models.CustomNote;
import com.payu.base.models.ErrorResponse;
import com.payu.base.models.PayUPaymentParams;
import com.payu.base.models.PayUSIParams;
import com.payu.base.models.PaymentMode;
import com.payu.base.models.PaymentType;
import com.payu.checkoutpro.PayUCheckoutPro;
import com.payu.checkoutpro.models.PayUCheckoutProConfig;
import com.payu.checkoutpro.utils.PayUCheckoutProConstants;
import com.payu.ui.model.listeners.PayUCheckoutProListener;
import com.payu.ui.model.listeners.PayUHashGenerationListener;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.security.Key;
import java.security.MessageDigest;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.util.HashMap;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import okhttp3.OkHttpClient;
import okhttp3.Request;

public class GooglePayActivity extends AppCompatActivity {

//    private ReviewOrderRecyclerViewAdapter reviewOrderAdapter;

    private final String email = "snooze@payu.in";
    private final String phone = "9999999999";
    private final String merchantName = "RH Group";
    private final String surl = "https://payuresponse.firebaseapp.com/success";
    private final String furl = "https://payuresponse.firebaseapp.com/failure";
    private String amount = "1.0";
    private final String testKey = "IUIaFM";
    private final String testSalt = "<Please_add_salt_here>";

    private final String testMerchantAccessKey = "<Please_add_your_merchant_access_key>";
    private final String testMerchantSecretKey = "<Please_add_your_merchant_secret_key>";

    private final String prodKey = "4rSUUA";
    private final String prodSalt = "UOssuafMZyn3LqkKnCwKyGBLG94uY6kj";

    private long mLastClickTime;


    private Connection connection;


    Button PayButton;

    String UMobileNo,Upassword,Uemail,UFullName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_google_pay);

        PayButton=findViewById(R.id.paynow);
        Intent intent = getIntent();
        amount = intent.getStringExtra("amount");


        PayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startPayment();
//                Toast.makeText(GooglePayActivity.this, "Don't press back press ", Toast.LENGTH_SHORT).show();
            }
        });


    }

    public void startPayment() {
        // Preventing multiple clicks, using threshold of 1 second
        if (SystemClock.elapsedRealtime() - mLastClickTime < 1000)
            return;
        mLastClickTime = SystemClock.elapsedRealtime();
        initUiSdk(preparePayUBizParams());

    }

    private PayUPaymentParams preparePayUBizParams() {

        String purpose = "App Memeber Registration";
        HashMap<String, Object> additionalParams = new HashMap<>();
        additionalParams.put(PayUCheckoutProConstants.CP_UDF1, "udf1");
        additionalParams.put(PayUCheckoutProConstants.CP_UDF2, "udf2");
        additionalParams.put(PayUCheckoutProConstants.CP_UDF3, "udf3");
        additionalParams.put(PayUCheckoutProConstants.CP_UDF4, "udf4");
        additionalParams.put(PayUCheckoutProConstants.CP_UDF5, "udf5");


        PayUSIParams siDetails = null;


        PayUPaymentParams.Builder builder = new PayUPaymentParams.Builder();
        builder.setAmount(amount)
                .setIsProduction(true)
                .setProductInfo(purpose)
                .setKey(prodKey)
                .setPhone("9850202777")
                .setTransactionId(String.valueOf(System.currentTimeMillis()))
                .setFirstName("rahul")
                .setEmail("rahulpawar9766@gmail.com")
                .setSurl(surl)
                .setFurl(furl)
                .setUserCredential(prodKey + ":rahulpawar9766@gmail.com")
                .setAdditionalParams(additionalParams)
                .setPayUSIParams(siDetails);
        PayUPaymentParams payUPaymentParams = builder.build();
        return payUPaymentParams;
    }

    private void initUiSdk(PayUPaymentParams payUPaymentParams) {
        PayUCheckoutPro.open(
                this,
                payUPaymentParams,
                getCheckoutProConfig(),
                new PayUCheckoutProListener() {

                    @Override
                    public void onPaymentSuccess(Object response) {


                        try {
                            showAlertDialog(response);
                        } catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onPaymentFailure(Object response) {
                        try {

                        } catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onPaymentCancel(boolean isTxnInitiated) {
                        //  showSnackBar(getResources().getString(R.string.transaction_cancelled_by_user));
                        try {
                        } catch (Exception exception) {
                            exception.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ErrorResponse errorResponse) {
                        String errorMessage = errorResponse.getErrorMessage();
                        if (TextUtils.isEmpty(errorMessage))
                            // errorMessage = getResources().getString(R.string.some_error_occurred);
                            //  showSnackBar(errorMessage);
                            System.out.println("n");
                    }

                    @Override
                    public void setWebViewProperties(@Nullable WebView webView, @Nullable Object o) {
                        //For setting webview properties, if any. Check Customized Integration section for more details on this
                    }

                    @Override
                    public void generateHash(HashMap<String, String> valueMap, PayUHashGenerationListener hashGenerationListener) {
                        String hashName = valueMap.get(PayUCheckoutProConstants.CP_HASH_NAME);
                        String hashData = valueMap.get(PayUCheckoutProConstants.CP_HASH_STRING);
                        if (!TextUtils.isEmpty(hashName) && !TextUtils.isEmpty(hashData)) {
                            //Generate Hash from your backend here
                            String hash = null;
                            if (hashName.equalsIgnoreCase(PayUCheckoutProConstants.CP_LOOKUP_API_HASH)){
                                //Calculate HmacSHA1 HASH for calculating Lookup API Hash
                                ///Do not generate hash from local, it needs to be calculated from server side only. Here, hashString contains hash created from your server side.

                                hash = calculateHmacSHA1Hash(hashData, testMerchantSecretKey);
                            } else {

                                //Calculate SHA-512 Hash here
                                hash = calculateHash(hashData + prodSalt);
                            }

                            HashMap<String, String> dataMap = new HashMap<>();
                            dataMap.put(hashName, hash);
                            hashGenerationListener.onHashGenerated(dataMap);
                        }
                    }
                }
        );
    }

    private String calculateHash(String hashString) {
        try {
            MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
            messageDigest.update(hashString.getBytes());
            byte[] mdbytes = messageDigest.digest();
            return getHexString(mdbytes);
        }catch (Exception e){
            e.printStackTrace();
            return "";
        }
    }

    private String calculateHmacSHA1Hash(String data, String key) {
        String HMAC_SHA1_ALGORITHM = "HmacSHA1";
        String result = null;

        try {
            Key signingKey = new SecretKeySpec(key.getBytes(), HMAC_SHA1_ALGORITHM);
            Mac mac = Mac.getInstance(HMAC_SHA1_ALGORITHM);
            mac.init(signingKey);
            byte[] rawHmac = mac.doFinal(data.getBytes());
            result = getHexString(rawHmac);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }
    private String getHexString(byte[] array){
        StringBuilder hash = new StringBuilder();
        for (byte hashByte : array) {
            hash.append(Integer.toString((hashByte & 0xff) + 0x100, 16).substring(1));
        }
        return hash.toString();
    }

    private void showAlertDialog(Object response) throws JSONException {
        String me=null;
        String txnid=null;
        String id=null;
        HashMap<String,Object> result = (HashMap<String, Object>) response;
        try {


            JSONArray contacts = new JSONArray();
            try{
                JSONObject emp=(new JSONObject((String) result.get(PayUCheckoutProConstants.CP_PAYU_RESPONSE)));
                me=emp.getString("status");
                txnid=emp.getString("txnid");
                id=emp.getString("id");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            //   HashMap<String,Object> result = (HashMap<String, Object>) response;
            new AlertDialog.Builder(this)
                    .setCancelable(false)
                    .setMessage("Response"+me)



                    .setPositiveButton("Ok", new DialogInterface.OnClickListener(){
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    }).show();

            if(me.equals("success"))
            {
                UpdateCurrentPlan(id,txnid);

            }else {
                Toast.makeText(GooglePayActivity.this,"Payment fail",Toast.LENGTH_SHORT).show();
                finish();
            }
        }
        catch (Exception ex)
        {}

    }

    private void UpdateCurrentPlan(String Order_id, String txn_id) {

        StrictMode.ThreadPolicy policy1 = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy1);

        OkHttpClient client1 = new OkHttpClient();
        okhttp3.Request request1 = new Request.Builder()
                .url("http://www.testproject.life/vendingdata.php?id=1&quantity='"+amount+"'")
                .build();
        try {
            okhttp3.Response response1 = client1.newCall(request1).execute();
            String responseString = response1.body().string();
            System.out.println(responseString);
            if(responseString.equals("submitted Successfull"))
            {
                Toast.makeText(getApplicationContext(), "submitted Successfull", Toast.LENGTH_SHORT).show();

            }
        }
        catch (Exception ex)
        {

        }



    }

    private PayUCheckoutProConfig getCheckoutProConfig()
    {
        PayUCheckoutProConfig checkoutProConfig = new PayUCheckoutProConfig();
        checkoutProConfig.setPaymentModesOrder(getCheckoutOrderList());
        // checkoutProConfig.setOfferDetails(getOfferDetailsList());
//        checkoutProConfig.setEnforcePaymentList(getEnforcePaymentList());
        checkoutProConfig.setShowCbToolbar(false);
        checkoutProConfig.setAutoSelectOtp(true);
        checkoutProConfig.setAutoApprove(true);
        checkoutProConfig.setSurePayCount(Integer.parseInt("0"));
        checkoutProConfig.setShowExitConfirmationOnPaymentScreen(false);
        checkoutProConfig.setShowExitConfirmationOnCheckoutScreen(false);
        checkoutProConfig.setMerchantName("Grain ATm machine");
        // checkoutProConfig.setMerchantLogo(R.drawable.mer1);
        checkoutProConfig.setWaitingTime(30000);
        checkoutProConfig.setMerchantResponseTimeout(30000);
        checkoutProConfig.setCustomNoteDetails(getCustomeNoteList());
//        if (reviewOrderAdapter != null)
//            checkoutProConfig.setCartDetails(reviewOrderAdapter.getOrderDetailsList());
    return checkoutProConfig;
    }
    public ArrayList<CustomNote> getCustomeNoteList(){

        ArrayList<CustomNote> customNote = new ArrayList<>();
        String str="null";
        if(str.equals("null"))
        {
            ArrayList<PaymentType> noteCategory = new ArrayList<>();
            // noteCategory.add( PaymentType.valueOf("hello"));
            //  CustomNote customNote1 = new CustomNote("hello", noteCategory);
            //  customNote1.setCustom_note("hello");
            //  customNote1.setCustom_note_category(noteCategory);
            //  customNote.add(customNote1);
        }
        else if(((AppCompatSpinner)findViewById(R.id.et_custom_note_category_value)).getSelectedItem().toString().equalsIgnoreCase("NULL")){
            CustomNote customNote1 = new CustomNote(((EditText)findViewById(R.id.et_custom_note_value)).getText().toString(), null);
            customNote1.setCustom_note(((EditText)findViewById(R.id.et_custom_note_value)).getText().toString());
            customNote1.setCustom_note_category(null);
            customNote.add(customNote1);
        }else {
            ArrayList<PaymentType> noteCategory = new ArrayList<>();
            noteCategory.add( PaymentType.CARD);
            noteCategory.add(PaymentType.NB);
            noteCategory.add(PaymentType.UPI_INTENT);
            noteCategory.add(PaymentType.WALLET);
            noteCategory.add(PaymentType.EMI);
            noteCategory.add(PaymentType.UPI);
            CustomNote customNote1 = new CustomNote(((EditText)findViewById(R.id.et_custom_note_value)).getText().toString(), noteCategory);
            customNote1.setCustom_note(((EditText)findViewById(R.id.et_custom_note_value)).getText().toString());
            customNote1.setCustom_note_category(noteCategory);
            customNote.add(customNote1);
        }

        return customNote;
    }



    private ArrayList<PaymentMode> getCheckoutOrderList() {
        ArrayList<PaymentMode> checkoutOrderList = new ArrayList();

        checkoutOrderList.add(new PaymentMode(PaymentType.UPI, PayUCheckoutProConstants.CP_GOOGLE_PAY));

        checkoutOrderList.add(new PaymentMode(PaymentType.WALLET, PayUCheckoutProConstants.CP_PHONEPE));

        checkoutOrderList.add(new PaymentMode(PaymentType.WALLET, PayUCheckoutProConstants.CP_PAYTM));

        return checkoutOrderList;
    }

}