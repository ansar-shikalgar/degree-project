package com.example.CompetitionEventManagementSystem;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.CompetitionEventManagementSystem.R;

public class Login extends AppCompatActivity {
    Button Login,Register;
    EditText Username,Password;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        sharedPreferences = getSharedPreferences("LoginData", Context.MODE_PRIVATE);
        String UName = sharedPreferences.getString("UserName","");
        if (!(UName.isEmpty())){
            Intent intent = new Intent(Login.this, Dashboard.class);
            intent.putExtra("UserName", UName);
            startActivity(intent);
            finishAffinity();
        } 

        Username = findViewById(R.id.uname);
        Password = findViewById(R.id.upass);



        Login = findViewById(R.id.LogIn);
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String UN = Username.getText().toString().trim();
                String Pass = Password.getText().toString().trim();

                if (UN.isEmpty()|| Pass.isEmpty()){
                    Toast.makeText(Login.this, "All field Require", Toast.LENGTH_SHORT).show();
                } else validation(UN, Pass);
            }
        });
    }

    private void validation(String un, String pass) {

        ProgressDialog progressDialog = new ProgressDialog(Login.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        String url = "http://www.testproject.info/CollageEventManagment/ClgEventMan_Login.php?UserName=" + un + "&Password=" + pass;

        StringRequest request = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        if (response.equals("notfound")) {
                            Toast.makeText(Login.this, "Please enter valid Username number and password", Toast.LENGTH_SHORT).show();
                        } else {
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("UserName", un);
                            editor.apply();

                            Toast.makeText(Login.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(Login.this, Dashboard.class);
                            intent.putExtra("UserName", un);
                            startActivity(intent);
                            finishAffinity();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(Login.this, "Something went wrong, try later..", Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue queue = Volley.newRequestQueue(Login.this);
        queue.add(request);
    }
}