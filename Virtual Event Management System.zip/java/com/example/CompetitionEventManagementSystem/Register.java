package com.example.CompetitionEventManagementSystem;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.CompetitionEventManagementSystem.R;

public class Register extends AppCompatActivity {
    Button register,login;
    EditText Fnmae,Mobile,Email,UN,Pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);

        Fnmae= findViewById(R.id.name);
        Mobile = findViewById(R.id.mob);
        Email = findViewById(R.id.email);
        UN = findViewById(R.id.Uname);
        Pass = findViewById(R.id.Upass);

        login = findViewById(R.id.log);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i4 = new Intent(Register.this, Login.class);
                startActivity(i4);
            }
        });

        register = findViewById(R.id.reg);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = Fnmae.getText().toString().trim();
                String Mob = Mobile.getText().toString().trim();
                String email = Email.getText().toString().trim();
                String Uname = UN.getText().toString().trim();
                String password = Pass.getText().toString().trim();

                if (name.isEmpty()||Mob.isEmpty()|| email.isEmpty() || Uname.isEmpty()|| password.isEmpty())
                {
                    Toast.makeText(Register.this, "All fields are required", Toast.LENGTH_SHORT).show();
                }
                else if (Mob.length() != 10 || !Mob.matches("\\d+")) {
                    Toast.makeText(Register.this, "Mobile number must be 10 digits", Toast.LENGTH_SHORT).show();
                }
                else {
                    register(name,Mob,email,Uname,password);
                }
            }
        });
            }

    private void register(String name, String mob, String email, String uname, String password) {


        ProgressDialog progressDialog = new ProgressDialog(Register.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        // Construct URL with query parameters
        String url = "http://www.testproject.info/CollageEventManagment/ClgEventMan_register.php?FName=" + name +
                "&Mobile=" + mob + "&Email=" + email + "&UserName=" + uname + "&Password=" + password;

        // Make GET request using Volley
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("response", response);

                // Check response from PHP script
                if (response.equals("Inserted")) {
                    Toast.makeText(Register.this, "Registration successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Register.this, Login.class));
                    finishAffinity();
                } else {
                    Toast.makeText(Register.this, "Registration failed: " + response, Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Register.this, "Something went wrong. Try later.", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });

        // Create a request queue and add the request
        RequestQueue queue = Volley.newRequestQueue(Register.this);
        queue.add(request);
    }
}



