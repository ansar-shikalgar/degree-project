package com.example.CompetitionEventManagementSystem.Adapter;

import android.content.Context;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.CompetitionEventManagementSystem.Fragment.F_Student_RegEvent;
import com.example.CompetitionEventManagementSystem.Model.ModelViewEvent;
import com.example.CompetitionEventManagementSystem.R;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

public class AdapterAllEvents extends  RecyclerView.Adapter<AdapterAllEvents.ViewHolder>{

    private Context context;
    private List<ModelViewEvent> modelViewEvents;

    public AdapterAllEvents(Context context, List<ModelViewEvent> eventList) {
        this.context = context;
        this.modelViewEvents = eventList;
    }
    @NonNull
    @Override
    public AdapterAllEvents.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each trainer item
        View view = LayoutInflater.from(context).inflate(R.layout.allevents, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterAllEvents.ViewHolder holder, int position) {

        ModelViewEvent event = modelViewEvents.get(position);

        // Set other trainer details
        holder.eventName.setText(event.getEventName());
        holder.eventCategory.setText(event.getEventCategory());
        // Handle the date formatting (if needed)
        String eventDate = String.valueOf(event.getEventDate());
        if (!eventDate.equals("Unknown")) {
            // Parse and format the date
            SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat newFormat = new SimpleDateFormat("dd-MM-yyyy");

            try {
                Date date = originalFormat.parse(eventDate);
                holder.eventdate.setText(newFormat.format(date));  // Format the date
            } catch (ParseException e) {
                holder.eventdate.setText(eventDate);  // If parsing fails, show the original date
            }
        } else {
            holder.eventdate.setText(eventDate);
        }
        holder.eventtime.setText(event.getEventTime());
        holder.eventfee.setText("$" + event.getEventFee());
        //holder.eventfee.setText(String.format("$%s", event.getEventFee()));


        // Load the image using Picasso
        String imageUrl = event.getimgpath();  // Corrected to use Imgpath
        if (imageUrl != null && !imageUrl.isEmpty()) {
            Picasso.get()
                    .load(imageUrl)  // Load image from URL// Optional: Add an error image if loading fails
                    .into(holder.eventImageView);  // Set the image to the ImageView
        }

    }

    @Override
    public int getItemCount() {
        return modelViewEvents.size();
    }

    // ViewHolder to hold each trainer's details and the ImageView
    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView eventImageView;  // ImageView for the trainer image
        TextView eventName, eventCategory, eventdate, eventtime, eventfee;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            // Initialize views
            eventImageView = itemView.findViewById(R.id.event_image);
            eventName = itemView.findViewById(R.id.name3);
            eventCategory = itemView.findViewById(R.id.Cat3);
            eventdate = itemView.findViewById(R.id.date3);
            eventtime = itemView.findViewById(R.id.time3);
            eventfee = itemView.findViewById(R.id.fee3);
        }
    }
}
