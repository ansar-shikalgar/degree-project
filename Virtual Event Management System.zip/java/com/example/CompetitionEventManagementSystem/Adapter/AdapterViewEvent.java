package com.example.CompetitionEventManagementSystem.Adapter;

import android.content.Context;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.CompetitionEventManagementSystem.Fragment.F_Student_RegEvent;
import com.squareup.picasso.Picasso;  // Import Picasso
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.CompetitionEventManagementSystem.Model.ModelViewEvent;
import com.example.CompetitionEventManagementSystem.R;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

public class AdapterViewEvent extends  RecyclerView.Adapter<AdapterViewEvent.ViewHolder>{

    private Context context;
    private List<ModelViewEvent> modelViewEvents;

    public AdapterViewEvent(Context context, List<ModelViewEvent> eventList) {
        this.context = context;
        this.modelViewEvents = eventList;
    }
    @NonNull
    @Override
    public AdapterViewEvent.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each trainer item
        View view = LayoutInflater.from(context).inflate(R.layout.viewevent, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterViewEvent.ViewHolder holder, int position) {

        ModelViewEvent event = modelViewEvents.get(position);

        // Set other trainer details
        holder.eventName.setText(event.getEventName());
        holder.eventCategory.setText(event.getEventCategory());
        // Handle the date formatting (if needed)
        String eventDate = String.valueOf(event.getEventDate());
        if (!eventDate.equals("Unknown")) {
            // Parse and format the date
            SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat newFormat = new SimpleDateFormat("dd-MM-yyyy");

            try {
                Date date = originalFormat.parse(eventDate);
                holder.eventdate.setText(newFormat.format(date));  // Format the date
            } catch (ParseException e) {
                holder.eventdate.setText(eventDate);  // If parsing fails, show the original date
            }
        } else {
            holder.eventdate.setText(eventDate);
        }
        holder.eventtime.setText(event.getEventTime());
        holder.eventfee.setText(event.getEventFee());

        // Load the image using Picasso
        String imageUrl = event.getimgpath();  // Corrected to use Imgpath
        if (imageUrl != null && !imageUrl.isEmpty()) {
            Picasso.get()
                    .load(imageUrl)  // Load image from URL// Optional: Add an error image if loading fails
                    .into(holder.eventImageView);  // Set the image to the ImageView
        }

        // Handle "Register" button click
        holder.registerButton.setOnClickListener(v -> {
            F_Student_RegEvent fragment = new F_Student_RegEvent();
            Bundle args = new Bundle();
            args.putString("eventName", event.getEventName());
            args.putString("eventCategory", event.getEventCategory());
            args.putString("eventDate", String.valueOf(event.getEventDate()));
            args.putString("eventTime", event.getEventTime());
            args.putString("EntryFee", event.getEventFee());
            fragment.setArguments(args);

            // Replace the fragment
            if (context instanceof FragmentActivity) {
                FragmentActivity fragmentActivity = (FragmentActivity) context;
                fragmentActivity.getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_container, fragment)
                        .addToBackStack(null)
                        .commit();
            } else {
                Toast.makeText(context, "Unable to open event details", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public int getItemCount() {
        return modelViewEvents.size();
    }

    // ViewHolder to hold each trainer's details and the ImageView
    public static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView eventImageView;  // ImageView for the trainer image
        TextView eventName, eventCategory, eventdate, eventtime, eventfee;
        Button registerButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            // Initialize views
            eventImageView = itemView.findViewById(R.id.event_image);
            eventName = itemView.findViewById(R.id.event_title);
            eventCategory = itemView.findViewById(R.id.category_text);
            eventdate = itemView.findViewById(R.id.date_text);
            eventtime = itemView.findViewById(R.id.time_text);
            eventfee = itemView.findViewById(R.id.fee_text);
            registerButton = itemView.findViewById(R.id.register_button);
        }
    }
}
