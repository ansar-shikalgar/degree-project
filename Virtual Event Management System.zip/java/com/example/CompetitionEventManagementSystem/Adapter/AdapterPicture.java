package com.example.CompetitionEventManagementSystem.Adapter;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.CompetitionEventManagementSystem.Fragment.F_Student_RegEvent;
import com.example.CompetitionEventManagementSystem.Model.ModelPicture;
import com.example.CompetitionEventManagementSystem.R;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AdapterPicture extends RecyclerView.Adapter<AdapterPicture.ViewHolder> {

    private Context context;
    private List<ModelPicture> modelPictureList;
    private static final int STORAGE_PERMISSION_CODE = 101;

    public AdapterPicture(Context context, List<ModelPicture> modelPictureList) {
        this.context = context;
        this.modelPictureList = modelPictureList;
    }

    @NonNull
    @Override
    public AdapterPicture.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each item
        View view = LayoutInflater.from(context).inflate(R.layout.event_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterPicture.ViewHolder holder, int position) {
        ModelPicture picture = modelPictureList.get(position);

        // Set the event name
        holder.eventName.setText(picture.getEventName());

        // Load images using Picasso
        loadImage(holder.image1, picture.getImgPath1());
        loadImage(holder.image2, picture.getImgPath2());
        loadImage(holder.image3, picture.getImgPath3());
        loadImage(holder.image4, picture.getImgPath4());

        // Handle "Download picture" button click
        holder.downloadButton.setOnClickListener(v -> {
            if (checkPermission()) {
                downloadImages(picture);
            } else {
                requestPermission();
            }
        });
    }

    private boolean checkPermission() {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions((android.app.Activity) context, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
    }

    private void downloadImages(ModelPicture picture) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                saveImageToStorage(picture.getImgPath1(), "image1");
                saveImageToStorage(picture.getImgPath2(), "image2");
                saveImageToStorage(picture.getImgPath3(), "image3");
                saveImageToStorage(picture.getImgPath4(), "image4");

                ((android.app.Activity) context).runOnUiThread(() ->
                        Toast.makeText(context, "Images downloaded successfully", Toast.LENGTH_SHORT).show()
                );
            } catch (Exception e) {
                ((android.app.Activity) context).runOnUiThread(() ->
                        Toast.makeText(context, "Failed to download images", Toast.LENGTH_SHORT).show()
                );
                e.printStackTrace();
            }
        });
    }


    private void saveImageToStorage(String imageUrl, String fileNamePrefix) throws Exception {
        if (imageUrl == null || imageUrl.isEmpty()) return;

        URL url = new URL(imageUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setDoInput(true);
        connection.connect();

        InputStream inputStream = connection.getInputStream();

        // Create the directory if it doesn't exist
        File directory = new File(Environment.getExternalStorageDirectory(), "EventImages");
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // Generate a unique file name using timestamp
        String uniqueFileName = fileNamePrefix + "_" + System.currentTimeMillis() + ".jpg";

        // Save the image file
        File file = new File(directory, uniqueFileName);
        FileOutputStream outputStream = new FileOutputStream(file);

        byte[] buffer = new byte[1024];
        int length;
        while ((length = inputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, length);
        }

        outputStream.close();
        inputStream.close();
    }

    @Override
    public int getItemCount() {
        return modelPictureList.size();
    }

    private void loadImage(ImageView imageView, String imageUrl) {
        if (imageUrl != null && !imageUrl.isEmpty()) {
            Picasso.get()
                    .load(imageUrl)
                    .placeholder(R.drawable.ic_placeholder) // Placeholder image
                    .error(R.drawable.ic_placeholder)      // Error image
                    .into(imageView);
        } else {
            imageView.setImageResource(R.drawable.ic_placeholder);
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView image1, image2, image3, image4; // Four ImageViews
        TextView eventName;
        Button downloadButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            // Initialize views
            image1 = itemView.findViewById(R.id.image1);
            image2 = itemView.findViewById(R.id.image2);
            image3 = itemView.findViewById(R.id.image3);
            image4 = itemView.findViewById(R.id.image4);
            eventName = itemView.findViewById(R.id.eName);

            downloadButton = itemView.findViewById(R.id.downloadBtn);
        }
    }
}
