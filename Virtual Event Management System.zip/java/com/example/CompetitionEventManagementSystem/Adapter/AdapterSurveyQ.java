package com.example.CompetitionEventManagementSystem.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.CompetitionEventManagementSystem.Model.ModelSurveyQ;
import com.example.CompetitionEventManagementSystem.R;

import java.util.List;

public class AdapterSurveyQ extends RecyclerView.Adapter<AdapterSurveyQ.ViewHolder> {

    private Context context;
    private List<ModelSurveyQ> modelSurveyQ;
    private String EventN;
    private String userMob;

    public AdapterSurveyQ(Context context, List<ModelSurveyQ> qList, String EventN, String userMob) {
        this.context = context;
        this.modelSurveyQ = qList;
        this.EventN = EventN;
        this.userMob = userMob;
    }

    @NonNull
    @Override
    public AdapterSurveyQ.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.survey_que, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterSurveyQ.ViewHolder holder, int position) {
        ModelSurveyQ model = modelSurveyQ.get(position);

        holder.QueID.setText(model.getQid());
        holder.Que.setText(model.getQuestions());

        // Clear previous listeners to avoid conflicts
        holder.optionsGroup.setOnCheckedChangeListener(null);

        // Restore previous selection if available
        String selectedAnswer = model.getAnswer();
        if ("Good".equals(selectedAnswer)) {
            holder.optionsGroup.check(R.id.radio_good);
        } else if ("Better".equals(selectedAnswer)) {
            holder.optionsGroup.check(R.id.radio_better);
        } else if ("Best".equals(selectedAnswer)) {
            holder.optionsGroup.check(R.id.radio_best);
        } else {
            holder.optionsGroup.clearCheck();
        }

        holder.optionsGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radio_good) {
                model.setAnswer("Good");
            } else if (checkedId == R.id.radio_better) {
                model.setAnswer("Better");
            } else if (checkedId == R.id.radio_best) {
                model.setAnswer("Best");
            }
        });

    }

    @Override
    public int getItemCount() {
        return modelSurveyQ.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView QueID, Que;
        RadioGroup optionsGroup;
        RadioButton radioGood, radioBetter, radioBest;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            QueID = itemView.findViewById(R.id.Q_ID);
            Que = itemView.findViewById(R.id.Que);
            optionsGroup = itemView.findViewById(R.id.optionsGroup);
            radioGood = itemView.findViewById(R.id.radio_good);
            radioBetter = itemView.findViewById(R.id.radio_better);
            radioBest = itemView.findViewById(R.id.radio_best);
        }
    }

    // Optional: Call this method to get all answers from the adapter
    public List<ModelSurveyQ> getAllAnswers() {
        return modelSurveyQ;
    }
}
