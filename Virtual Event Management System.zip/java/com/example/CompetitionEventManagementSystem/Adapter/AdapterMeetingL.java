package com.example.CompetitionEventManagementSystem.Adapter;

import android.content.Context;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.CompetitionEventManagementSystem.Model.ModelMeetingL;
import com.example.CompetitionEventManagementSystem.R;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AdapterMeetingL extends  RecyclerView.Adapter<AdapterMeetingL.ViewHolder>{

    private Context context;
    private List<ModelMeetingL> modelMeetingL;
    private String userMob;

    public AdapterMeetingL(Context context, List<ModelMeetingL> modelMeetingLList, String userMob) {
        this.context = context;
        this.modelMeetingL = modelMeetingLList;
        this.userMob = userMob;
    }
    @NonNull
    @Override
    public AdapterMeetingL.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each trainer item
        View view = LayoutInflater.from(context).inflate(R.layout.viewmeetl, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterMeetingL.ViewHolder holder, int position) {

        ModelMeetingL event = modelMeetingL.get(position);

        // Set event name
        holder.eventName.setText(event.getEventname());

        String eventDate = event.getEventdate();

        // Format and display event date
        SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat newFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());

        try {
            Date date = originalFormat.parse(eventDate);
            String formattedDate = newFormat.format(date);
            holder.eventdate.setText(formattedDate);

            // Compare with today's date
            String today = originalFormat.format(new Date());

            if (eventDate.equals(today)) {
                // It's today's event, show link and button
                holder.Link.setVisibility(View.VISIBLE);
                holder.Link.setText(event.getEventLink());
                holder.join.setVisibility(View.VISIBLE);
            } else {
                // Not today's event, hide link and button
                holder.Link.setVisibility(View.GONE);
                holder.join.setVisibility(View.GONE);
            }

        } catch (ParseException e) {
            // If parsing fails, show raw date and hide link
            holder.eventdate.setText(eventDate);
            holder.Link.setVisibility(View.GONE);
            holder.join.setVisibility(View.GONE);
        }

        holder.eventtime.setText(event.getEventtime());

        holder.join.setOnClickListener(v -> {
            // Open the link in Chrome
            String url = event.getEventLink();
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.setPackage("com.android.chrome");

            try {
                context.startActivity(intent);
            } catch (android.content.ActivityNotFoundException ex) {
                intent.setPackage(null);
                context.startActivity(intent);
            }

            // Send data to PHP API using Volley
            String apiUrl = "http://www.testproject.info/CollageEventManagment/CompetitionEventManS_MeetingDetails.php";

            RequestQueue queue = Volley.newRequestQueue(context);
            StringRequest request = new StringRequest(Request.Method.POST, apiUrl,
                    response -> {
                        Log.d("VolleySuccess", "URL: " + apiUrl);
                        Log.d("VolleySuccess", "Response: " + response);
                        Toast.makeText(context, "Registered successfully!", Toast.LENGTH_SHORT).show();
                    },
                    error -> {
                        Log.e("VolleyError", "URL: " + apiUrl);
                        Log.e("VolleyError", "Error: " + error.toString(), error);
                        Toast.makeText(context, "Error: " + error.getMessage(), Toast.LENGTH_LONG).show();
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("Event_id", String.valueOf(event.getEventId()));
                    params.put("Event_Name", event.getEventname());
                    params.put("Event_date", event.getEventdate());
                    params.put("Event_time", event.getEventtime());
                    params.put("eventlink", event.getEventLink());
                    params.put("Student_Username", userMob); // from constructor

                    Log.d("VolleyParams", "Params: " + params.toString());
                    return params;
                }
            };

            Log.d("VolleyRequest", "Sending request to: " + apiUrl);
            queue.add(request);
        });
    }

    @Override
    public int getItemCount() {
        return  modelMeetingL.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView eventName, Link, eventdate, eventtime;
        Button join;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            eventName = itemView.findViewById(R.id.event_title);
            eventdate = itemView.findViewById(R.id.date_text);
            eventtime = itemView.findViewById(R.id.time_text);
            Link = itemView.findViewById(R.id.fee_text);
            join = itemView.findViewById(R.id.join_button);

        }
    }
}
