package com.example.CompetitionEventManagementSystem.Adapter;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.example.CompetitionEventManagementSystem.Model.ModelSCertificate;
import com.example.CompetitionEventManagementSystem.R;
import com.squareup.picasso.Picasso;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AdapterSCertificate extends RecyclerView.Adapter<AdapterSCertificate.ViewHolder> {

    private Context context;
    private List<ModelSCertificate> modelSCertificates;
    private static final int STORAGE_PERMISSION_CODE = 101;

    public AdapterSCertificate(Context context, List<ModelSCertificate> modelSCertificates) {
        this.context = context;
        this.modelSCertificates = modelSCertificates;
    }

    @NonNull
    @Override
    public AdapterSCertificate.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.viewcertificate, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterSCertificate.ViewHolder holder, int position) {
        ModelSCertificate cert = modelSCertificates.get(position);

        // Set event name
        holder.eventName.setText(cert.getEventN());

        // Determine whether to show image or PDF download option
        String imageUrl = cert.getCimgpath();
        String pdfUrl = cert.getPdfpath();

        if (imageUrl != null && !imageUrl.isEmpty()) {
            // Display the image using Picasso
            holder.certiImageView.setVisibility(View.VISIBLE);
            Picasso.get()
                    .load(imageUrl)
                    .error(R.drawable.certificate) // Optional placeholder
                    .into(holder.certiImageView);

            // Handle image download
            holder.dButton.setText("Download Certificate");
            holder.dButton.setOnClickListener(v -> {
                if (checkPermission()) {
                    downloadCertificate(imageUrl, "certificate");
                } else {
                    requestPermission();
                }
            });
        } else if (pdfUrl != null && !pdfUrl.isEmpty()) {
            // Hide image view for PDF-only entries
            holder.certiImageView.setVisibility(View.GONE);

            // Handle PDF download
            holder.dButton.setText("Download PDF");
            holder.dButton.setOnClickListener(v -> {
                if (checkPermission()) {
                    downloadPDF(pdfUrl, "certificate");
                } else {
                    requestPermission();
                }
            });
        }
    }

    private boolean checkPermission() {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(
                (android.app.Activity) context,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                STORAGE_PERMISSION_CODE
        );
    }

    private void downloadCertificate(String imageUrl, String fileNamePrefix) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                saveCertificateToStorage(imageUrl, fileNamePrefix);

                ((android.app.Activity) context).runOnUiThread(() ->
                        Toast.makeText(context, "Certificate downloaded successfully", Toast.LENGTH_SHORT).show()
                );
            } catch (Exception e) {
                ((android.app.Activity) context).runOnUiThread(() ->
                        Toast.makeText(context, "Failed to download certificate", Toast.LENGTH_SHORT).show()
                );
                e.printStackTrace();
            }
        });
    }

    private void downloadPDF(String pdfUrl, String fileNamePrefix) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            try {
                savePDFToStorage(pdfUrl, fileNamePrefix);

                ((android.app.Activity) context).runOnUiThread(() ->
                        Toast.makeText(context, "PDF downloaded successfully", Toast.LENGTH_SHORT).show()
                );
            } catch (Exception e) {
                ((android.app.Activity) context).runOnUiThread(() ->
                        Toast.makeText(context, "Failed to download PDF", Toast.LENGTH_SHORT).show()
                );
                e.printStackTrace();
            }
        });
    }

    private void saveCertificateToStorage(String imageUrl, String fileNamePrefix) throws Exception {
        if (imageUrl == null || imageUrl.isEmpty()) return;

        // Establish a connection to the URL
        URL url = new URL(imageUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setDoInput(true);
        connection.connect();

        // Get the input stream
        InputStream inputStream = connection.getInputStream();

        // Create the directory for saving the certificate
        File directory = new File(Environment.getExternalStorageDirectory(), "EventCertificates");
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // Generate a unique file name
        String uniqueFileName = fileNamePrefix + "_" + System.currentTimeMillis() + ".jpg";

        // Save the image file
        File file = new File(directory, uniqueFileName);
        FileOutputStream outputStream = new FileOutputStream(file);

        byte[] buffer = new byte[1024];
        int length;
        while ((length = inputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, length);
        }

        outputStream.close();
        inputStream.close();
    }

    private void savePDFToStorage(String pdfUrl, String fileNamePrefix) throws Exception {
        if (pdfUrl == null || pdfUrl.isEmpty()) return;

        // Establish a connection to the URL
        URL url = new URL(pdfUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setDoInput(true);
        connection.connect();

        // Get the input stream
        InputStream inputStream = connection.getInputStream();

        // Create the directory for saving PDFs
        File directory = new File(Environment.getExternalStorageDirectory(), "EventCertificates");
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // Generate a unique file name
        String uniqueFileName = fileNamePrefix + "_" + System.currentTimeMillis() + ".pdf";

        // Save the PDF file
        File file = new File(directory, uniqueFileName);
        FileOutputStream outputStream = new FileOutputStream(file);

        byte[] buffer = new byte[1024];
        int length;
        while ((length = inputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, length);
        }

        outputStream.close();
        inputStream.close();
    }

    @Override
    public int getItemCount() {
        return modelSCertificates.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView certiImageView;
        TextView eventName;
        Button dButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            certiImageView = itemView.findViewById(R.id.cer_image);
            eventName = itemView.findViewById(R.id.nameE);
            dButton = itemView.findViewById(R.id.d_button);
        }
    }
}
