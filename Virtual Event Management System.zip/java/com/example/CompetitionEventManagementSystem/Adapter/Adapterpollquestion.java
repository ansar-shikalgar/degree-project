package com.example.CompetitionEventManagementSystem.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.CompetitionEventManagementSystem.Model.Modelpollallquestion;
import com.example.CompetitionEventManagementSystem.R;

import java.util.List;

public class Adapterpollquestion extends  RecyclerView.Adapter<Adapterpollquestion.ViewHolder>{
    private Context context;
    private List<Modelpollallquestion> list;
    public Adapterpollquestion(Context context, List<Modelpollallquestion> list) {
        this.context = context;
        this.list= list;
    }
    @NonNull
    @Override
    public Adapterpollquestion.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.pollquestionsdesign,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapterpollquestion.ViewHolder holder, int position) {
        Modelpollallquestion temp = list.get(position);
        String eventname = temp.getEventname();
        String Question = temp.getQuestion();
        String username = temp.getUsername();
        int Yes_Count = temp.getYescount();
        int No_Count = temp.getNocount();
        String DateTime = temp.getDatetime();

        holder.eventname .setText(eventname.equals("Unknown") ? "EventName: Unknown" : "EventName: " + eventname);
        holder.Question .setText(Question.equals("Unknown") ? "Question: Unknown" : "Question: " + Question);
        holder.username.setText(username.equals("Unknown") ? "username: Unknown" : "username: " + username );
        holder.Yes_Count.setText(Yes_Count == -1 ? "Yes_Count: Unknown" : "Yes_Count: " + Yes_Count);
        holder.No_Count.setText(No_Count == -1 ? "No_Count: Unknown" : "No_Count: " + No_Count);
        holder.DateTime.setText("DateTime: " + DateTime);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView eventname, Question, username, Yes_Count, No_Count, DateTime;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            eventname = itemView.findViewById(R.id.text_eventname);
            Question = itemView.findViewById(R.id.text_question);
            username = itemView.findViewById(R.id.text_username);
            Yes_Count = itemView.findViewById(R.id.text_yescount);
            No_Count = itemView.findViewById(R.id.text_nocount);
            DateTime = itemView.findViewById(R.id.text_Date_Time);


        }
    }
}
