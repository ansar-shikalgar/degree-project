package com.example.CompetitionEventManagementSystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Student_coordinator_admin_login extends AppCompatActivity {
Button studentlog,coordilog,adminlog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_student_coordinator_admin_login);
        studentlog=findViewById(R.id.sudentlogin);
        coordilog=findViewById(R.id.cordinatorlogin);
        adminlog=findViewById(R.id.adminlogin);
        studentlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(Student_coordinator_admin_login.this,StudentLogin.class);
                startActivity(intent1);
            }
        });
        coordilog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2=new Intent(Student_coordinator_admin_login.this,Login.class);
                startActivity(intent2);
            }
        });
        adminlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3=new Intent(Student_coordinator_admin_login.this,adminlogin.class);
                startActivity(intent3);
            }
        });

    }
}