package com.example.CompetitionEventManagementSystem;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class ImageProcessClass {

    // Define the callback interface
    public interface ImageHttpRequestListener {
        void onResponseReceived(String response);
        void onErrorReceived(String error);
    }

    public void ImageHttpRequest(String requestURL, HashMap<String, String> postData, ImageHttpRequestListener callback) {
        new HttpRequestTask(callback).execute(requestURL, postData);
    }

    // AsyncTask to handle network request off the main thread
    private static class HttpRequestTask extends AsyncTask<Object, Void, String> {

        private ImageHttpRequestListener callback;

        HttpRequestTask(ImageHttpRequestListener callback) {
            this.callback = callback;
        }

        @Override
        protected String doInBackground(Object... params) {
            String requestURL = (String) params[0];
            HashMap<String, String> postData = (HashMap<String, String>) params[1];
            StringBuilder stringBuilder = new StringBuilder();

            try {
                URL url = new URL(requestURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setReadTimeout(19000);
                httpURLConnection.setConnectTimeout(19000);
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoInput(true);
                httpURLConnection.setDoOutput(true);

                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                bufferedWriter.write(getPostDataString(postData));
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                int responseCode = httpURLConnection.getResponseCode();
                if (responseCode == HttpsURLConnection.HTTP_OK) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line);
                    }
                    bufferedReader.close();
                } else {
                    return "Error: " + responseCode;
                }

            } catch (IOException e) {
                e.printStackTrace();
                return "IOException: " + e.getMessage();
            }

            return stringBuilder.toString();
        }

        @Override
        protected void onPostExecute(String result) {
            if (callback != null) {
                if (result.startsWith("Error") || result.startsWith("IOException")) {
                    callback.onErrorReceived(result);
                } else {
                    callback.onResponseReceived(result);
                }
            }
        }
    }

    private static String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();

        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (result.length() > 0) result.append("&");
            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }
}
