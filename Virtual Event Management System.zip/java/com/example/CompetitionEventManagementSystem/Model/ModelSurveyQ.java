package com.example.CompetitionEventManagementSystem.Model;

public class ModelSurveyQ {


        private String qid;
        private String questions;
        private String EventN;
    private String answer; // user-selected option

    public String getQid() {
        return qid;
    }

    public void setQid(String qid) {
        this.qid = qid;
    }

    public String getQuestions() {
        return questions;
    }

    public void setQuestions(String questions) {
        this.questions = questions;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
}
