package com.example.CompetitionEventManagementSystem.Model;

public class ModelPicture {

    private String eventName;
    private String imgPath1;
    private String imgPath2;
    private String imgPath3;
    private String imgPath4;

    // Constructor
    public ModelPicture(String eventName, String imgPath1, String imgPath2, String imgPath3, String imgPath4) {
        this.eventName = eventName;
        this.imgPath1 = imgPath1;
        this.imgPath2 = imgPath2;
        this.imgPath3 = imgPath3;
        this.imgPath4 = imgPath4;
    }

    // Default Constructor
    public ModelPicture() {}

    // Getters and Setters
    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getImgPath1() {
        return imgPath1;
    }

    public void setImgPath1(String imgPath1) {
        this.imgPath1 = imgPath1;
    }

    public String getImgPath2() {
        return imgPath2;
    }

    public void setImgPath2(String imgPath2) {
        this.imgPath2 = imgPath2;
    }

    public String getImgPath3() {
        return imgPath3;
    }

    public void setImgPath3(String imgPath3) {
        this.imgPath3 = imgPath3;
    }

    public String getImgPath4() {
        return imgPath4;
    }

    public void setImgPath4(String imgPath4) {
        this.imgPath4 = imgPath4;
    }
}
