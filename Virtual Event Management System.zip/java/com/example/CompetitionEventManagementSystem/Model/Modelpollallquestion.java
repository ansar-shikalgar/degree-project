package com.example.CompetitionEventManagementSystem.Model;

public class Modelpollallquestion {
    private String eventname;
    private String question;
    private String username;
    private int yescount;
    private int nocount;
    private String datetime;

    // Constructor


    public Modelpollallquestion(String eventname, String question, String username, int yescount, int nocount, String datetime) {
        this.eventname = eventname;
        this.question = question;
        this.username = username;
        this.yescount = yescount;
        this.nocount = nocount;
        this.datetime = datetime;
    }

    // Getters
    public String getEventname() {
        return eventname;
    }

    public String getQuestion() {
        return question;
    }

    public String getUsername() {
        return username;
    }

    public int getYescount() {
        return yescount;
    }

    public int getNocount() {
        return nocount;
    }

    public String getDatetime() {
        return datetime;
    }

    // Setters
    public void setEventname(String eventname) {
        this.eventname = eventname;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setYescount(int yescount) {
        this.yescount = yescount;
    }

    public void setNocount(int nocount) {
        this.nocount = nocount;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }
}

