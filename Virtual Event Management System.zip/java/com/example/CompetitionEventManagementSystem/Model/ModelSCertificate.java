package com.example.CompetitionEventManagementSystem.Model;

public class ModelSCertificate {

    private String eventN;
    private String Cimgpath;
    private String pdfpath;
    private String Prn;

    // Getters and setters
    public String getEventN() {
        return eventN;
    }

    public void setEventN(String eventN) {
        this.eventN = eventN;
    }


    public String getCimgpath() {
        return Cimgpath;
    }

    public void setCimgpath(String Cimgpath) {
        this.Cimgpath = Cimgpath;
    }

    public String getPdfpath() {
        return pdfpath;
    }

    public void setPdfpath(String pdfpath) {
        this.pdfpath = pdfpath;
    }

    // Getter and setter for eventDate
    public String getPrn() {
        return Prn;
    }

    public void setPrn(String Prn) {
        this.Prn = Prn;
    }

}
