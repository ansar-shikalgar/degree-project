package com.example.CompetitionEventManagementSystem.Model;

public class ModelViewEvent {

    private String eventName;
    private String eventCategory;
    private String eventDate;
    private String eventTime;
    private String eventFee;
    private String imgpath1;  // Changed to Imgpath

    // Getters and setters
    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }


    public String getEventCategory() {
        return eventCategory;
    }

    public void setEventCategory(String eventCategory) {
        this.eventCategory = eventCategory;
    }

    // Getter and setter for eventDate
    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }

    public String getEventFee() {
        return eventFee;
    }

    public void setEventFee(String eventFee) {
        this.eventFee = eventFee;
    }

    public String getimgpath() {
        return imgpath1;  // Updated getter
    }

    public void setimgpath(String imgpath1) {
        this.imgpath1 = imgpath1;  // Updated setter
    }
}
