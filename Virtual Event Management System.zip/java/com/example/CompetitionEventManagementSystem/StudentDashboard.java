package com.example.CompetitionEventManagementSystem;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.CompetitionEventManagementSystem.Fragment.F_MeetingLink;
import com.example.CompetitionEventManagementSystem.Fragment.F_StudentDash;
import com.example.CompetitionEventManagementSystem.Fragment.F_Student_DCerti;
import com.example.CompetitionEventManagementSystem.Fragment.F_Student_Myprofile;
import com.example.CompetitionEventManagementSystem.Fragment.F_Student_ViewEvent;
import com.example.CompetitionEventManagementSystem.Fragment.ServeyAPolls;
import com.example.CompetitionEventManagementSystem.Fragment.ServeyQueS;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class StudentDashboard extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private static final String TAG = "StudentDashboard";
    private static final String PREF_LOGIN_DATA = "LoginData";
    private static final String KEY_MOBILE = "Mobile";

    private DrawerLayout drawerLayout;
    private String mobile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_dashboard);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolS1);
        setSupportActionBar(toolbar);

        // Setup Navigation Drawer
        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        // Setup ActionBarDrawerToggle
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Get the mobile number from the intent
        Intent intent = getIntent();
        mobile = intent.getStringExtra(KEY_MOBILE);
        Log.d(TAG, mobile != null ? "Mobile: " + mobile : "Mobile is null");

        getStatus(mobile);
        // Load Home fragment initially if no fragment is loaded
        if (savedInstanceState == null) {
            loadHomeFragment();
        }
    }

    private void getStatus(String mobile) {
        String url = "http://www.testproject.info/CollageEventManagment/CompetitionEventManS_CheckStatus.php";

        Log.d("getStatus-Mobile", "Mobile being sent: " + mobile);

        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    Log.d("StatusResponse", response);
                    try {
                        JSONObject jsonObject = new JSONObject(response);

                        if (jsonObject.getBoolean("success")) {
                            int status = jsonObject.getInt("Status");
                            String eventName = jsonObject.getString("Event_Name"); // extract Event_Name

                            Bundle bundle = new Bundle();
                            bundle.putString("Student_Username", mobile);
                            bundle.putString("Event_Name", eventName); // pass Event_Name to fragment

                            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();

                            if (status == 0) {
                                F_StudentDash dash = new F_StudentDash();
                                dash.setArguments(bundle);
                                fragmentTransaction.replace(R.id.fragment_container, dash);
                            } else if (status == 1) {
                                ServeyQueS survey = new ServeyQueS();
                                survey.setArguments(bundle);
                                fragmentTransaction.replace(R.id.fragment_container, survey);
                            }

                            fragmentTransaction.commit();
                        } else {
                            String message = jsonObject.optString("message", "Unknown error");
                            Toast.makeText(this, "Server Error: " + message, Toast.LENGTH_SHORT).show();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Error parsing server response", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Log.e("VolleyError", error.toString());
                    Toast.makeText(this, "Connection error", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("Student_Username", mobile);
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/x-www-form-urlencoded");
                return headers;
            }
        };

        queue.add(request);
    }

    private void loadHomeFragment() {
        Bundle bundle = new Bundle();
        bundle.putString("Mobile", mobile);
        F_StudentDash dash = new F_StudentDash();
        dash.setArguments(bundle);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, dash)
                .commit();
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        // Handle fragment switching based on menu item clicks
        if (id == R.id.nav_dashboard) {
            // Load Home fragment
            loadHomeFragment();
        }  else if (id == R.id.nav_Profile) {
            // Load MyProfile fragment
            F_Student_Myprofile SmyProfile = new F_Student_Myprofile();
            Bundle bundle = new Bundle();
            bundle.putString("Mobile", mobile);
            SmyProfile.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, SmyProfile)
                    .addToBackStack(null)  // Add to back stack
                    .commit();
        }else if (id == R.id.nav_viewEvent) {
            // Load AddEvent fragment
            F_Student_ViewEvent viewEvent = new F_Student_ViewEvent();
            Bundle bundle = new Bundle();
            bundle.putString("Mobile", mobile);
            viewEvent.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, viewEvent)
                    .addToBackStack(null)  // Add to back stack
                    .commit();

        }
        else if (id == R.id.nav_MeetingLink) {
            // Load AddEvent fragment
            F_MeetingLink viewlink = new F_MeetingLink();
            Bundle bundle = new Bundle();
            bundle.putString("Mobile", mobile);
            viewlink.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, viewlink)
                    .addToBackStack(null)  // Add to back stack
                    .commit();

        }
        else if (id == R.id.nav_serV) {
            // Load AddEvent fragment
            ServeyAPolls SAP = new ServeyAPolls();
            Bundle bundle = new Bundle();
            bundle.putString("Mobile", mobile);
            SAP.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, SAP)
                    .addToBackStack(null)  // Add to back stack
                    .commit();

        }
        else if (id == R.id.nav_DCerti) {
            // Load AddEvent fragment
            F_Student_DCerti dcertifi = new F_Student_DCerti();
            Bundle bundle = new Bundle();
            bundle.putString("Mobile", mobile);
            dcertifi.setArguments(bundle);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, dcertifi)
                    .addToBackStack(null)  // Add to back stack
                    .commit();
        }
        else if (id == R.id.logOut) {
            // Clear login session and navigate to the Login screen
            SharedPreferences sharedPreferences = getSharedPreferences("LoginData", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear();  // Clear all saved data
            editor.apply();

            Intent logoutIntent = new Intent(StudentDashboard.this, StudentLogin.class);
            logoutIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(logoutIntent);
            finish();  // Finish current activity to prevent going back to it
        }

        // Close the navigation drawer
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        // Close the navigation drawer if it is open
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
