package com.example.CompetitionEventManagementSystem;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class StudentRegister extends AppCompatActivity {
    Button register, login;
    EditText fullName, PRNno, mobile, email, password;
    Spinner branchSpinner, classSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_student_register);

        // Initialize UI components
        fullName = findViewById(R.id.names);
        PRNno = findViewById(R.id.prnNo);
        mobile = findViewById(R.id.mobS);
        email = findViewById(R.id.emailS);
        password = findViewById(R.id.passS);
        branchSpinner = findViewById(R.id.branchSpinner);
        classSpinner = findViewById(R.id.classSpinner);

        login = findViewById(R.id.logS);
        register = findViewById(R.id.regS);

        // Populate branchSpinner and classSpinner with data
        ArrayAdapter<CharSequence> branchAdapter = ArrayAdapter.createFromResource(this, R.array.branches, android.R.layout.simple_spinner_item);
        branchAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        branchSpinner.setAdapter(branchAdapter);

        ArrayAdapter<CharSequence> classAdapter = ArrayAdapter.createFromResource(this, R.array.classes, android.R.layout.simple_spinner_item);
        classAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        classSpinner.setAdapter(classAdapter);

        // Handle login button click
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StudentRegister.this, StudentLogin.class);
                startActivity(intent);
            }
        });

        // Handle register button click
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = fullName.getText().toString().trim();
                String PRNNO = PRNno.getText().toString().trim();
                String mob = mobile.getText().toString().trim();
                String emailText = email.getText().toString().trim();
                String selectedBranch = branchSpinner.getSelectedItem().toString();
                String selectedClass = classSpinner.getSelectedItem().toString();
                String pass = password.getText().toString().trim();

                // Validate fields
                if (name.isEmpty() || PRNNO.isEmpty() || mob.isEmpty() || emailText.isEmpty() || pass.isEmpty()) {
                    Toast.makeText(StudentRegister.this, "All fields are required", Toast.LENGTH_SHORT).show();
                } else if (mob.length() != 10 || !mob.matches("\\d+")) {
                    Toast.makeText(StudentRegister.this, "Mobile number must be 10 digits", Toast.LENGTH_SHORT).show();
                }
                else if (PRNNO.length() != 13 || !PRNNO.matches("\\d+")) {
                    Toast.makeText(StudentRegister.this, "PRN No must be 13 digits", Toast.LENGTH_SHORT).show();
                }else {
                    register(name,PRNNO, mob, emailText, selectedBranch, selectedClass, pass);
                }
            }
        });
    }

    private void register(String name, String PRNNNO, String mob, String emailText, String selectedBranch, String selectedClass, String pass) {

        ProgressDialog progressDialog = new ProgressDialog(StudentRegister.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        // Construct URL with query parameters
        String url = "http://www.testproject.info/CollageEventManagment/CompetitionEventManS_StudentRegister.php?FName=" + name + "&PRNNo=" + PRNNNO +
                "&Mobile=" + mob + "&Email=" + emailText + "&Branch=" + selectedBranch + "&Class=" + selectedClass + "&Password=" + pass;

        // Make GET request using Volley
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("response", response);

                // Check response from PHP script
                if (response.equals("Inserted")) {
                    Toast.makeText(StudentRegister.this, "Registration successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(StudentRegister.this, StudentLogin.class));
                    finishAffinity();
                } else {
                    Toast.makeText(StudentRegister.this, "Registration failed: " + response, Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(StudentRegister.this, "Something went wrong. Try later.", Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        });

        // Create a request queue and add the request
        RequestQueue queue = Volley.newRequestQueue(StudentRegister.this);
        queue.add(request);


    }

}
