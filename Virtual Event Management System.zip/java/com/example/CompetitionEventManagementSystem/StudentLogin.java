package com.example.CompetitionEventManagementSystem;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class StudentLogin extends AppCompatActivity {

    Button Login,Register, adminL;
    EditText Username,Password;
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_student_login);

        sharedPreferences = getSharedPreferences("LoginData", Context.MODE_PRIVATE);
        String mobile = sharedPreferences.getString("Mobile","");
        if (!(mobile.isEmpty())){
            Intent intent = new Intent(StudentLogin.this, StudentDashboard.class);
            intent.putExtra("Mobile", mobile);
            startActivity(intent);
            finishAffinity();

        }
        Username = findViewById(R.id.sname);
        Password = findViewById(R.id.spass);
        Register = findViewById(R.id.SReg);
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i3 = new Intent(StudentLogin.this,StudentRegister.class);
                startActivity(i3);
            }
        });

//        adminL = findViewById(R.id.ALogin);
//        adminL.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i10 = new Intent(StudentLogin.this,Login.class);
//                startActivity(i10);
//            }
//        });

        Login = findViewById(R.id.SLogIn);
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String mob = Username.getText().toString().trim();
                String Pass = Password.getText().toString().trim();

                if (mob.isEmpty()|| Pass.isEmpty()){
                    Toast.makeText(StudentLogin.this, "All field Require", Toast.LENGTH_SHORT).show();
                } else validation(mob, Pass);
            }
        });

    }

    private void validation(String mob, String pass) {
        ProgressDialog progressDialog = new ProgressDialog(StudentLogin.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please wait...");
        progressDialog.show();

        String url = "http://www.testproject.info/CollageEventManagment/CompetitionEventManS_StudentLogin.php?Mobile=" + mob + "&Password=" + pass;

        StringRequest request = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        if (response.equals("notfound")) {
                            Toast.makeText(StudentLogin.this, "Please enter valid Username number and password", Toast.LENGTH_SHORT).show();
                        } else {
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("Mobile", mob);
                            editor.apply();

                            Toast.makeText(StudentLogin.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(StudentLogin.this, StudentDashboard.class);
                            intent.putExtra("Mobile", mob);
                            startActivity(intent);
                            finishAffinity();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(StudentLogin.this, "Something went wrong, try later..", Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue queue = Volley.newRequestQueue(StudentLogin.this);
        queue.add(request);

    }
}